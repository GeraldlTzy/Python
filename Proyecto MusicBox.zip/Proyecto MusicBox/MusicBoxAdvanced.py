# --------------------------------------pygame setup--------------------------------------------------
import pygame
import time
import os
import shutil
import sys

# La biblioteca time se uso para el control de fps y para detener el programa 1 segundo para evitar errores a la hora de
# reemplazar archivos.
# Se puede encontrar mas informacion en el siguiente enlace: https://docs.python.org/3/library/time.html

# La biblioteca shutil se utilizo para la manipulacion de archivos como la eliminacion, copia o reubicacion de estos.
# Esta biblioteca cuenta con la participacion de toda la comunidad de python,
# incluyendo a Guido Van Rossum, creador de python.
# Se puede encontrar mas informacion en el siguiente enlace: https://docs.python.org/es/3/library/shutil.html

pygame.init()
screen = pygame.display.set_mode((1280, 720), pygame.RESIZABLE)  # Ventana principal
lista_reproduccion = pygame.Surface((1120, 500))  # Ventana secundaria
clock = pygame.time.Clock()  # Control de FPS
pygame.display.set_caption('Music Box Advanced')  # Nombre de la ventana
running = True
# Colocar fuentes de texto
fuente = pygame.font.SysFont('Liberation  Serif', 20)
# Cargar imagenes de fondo
fondo = pygame.image.load('fondo.jpg').convert()
fondo = pygame.transform.scale(fondo, (1280, 720))

# ----------------------------------------------------------------------------------------------------------------------
# -------------------------------------------Clases y sus Funciones-----------------------------------------------------
class boton:
    def __init__(self, texto, forma, colorBotones1, colorBotones2, colorTexto, superficie, anchoLinea, directorio=None,
                 scaleImagen=None, posImagen=None, color=None, color2=None):
        self.forma = forma
        self.color = color
        self.color2 = color2
        self.superficie = superficie
        self.texto = texto
        self.anchoLinea = anchoLinea
        self.directorio = directorio
        self.scaleImagen = scaleImagen
        self.posImagen = posImagen


    def pintarBotones(self):
        if self.forma.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(self.superficie, self.color,
                             self.forma, self.anchoLinea)
            texto = fuente.render(self.texto, True, (255, 255, 255))
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))
        else:
            pygame.draw.rect(self.superficie, self.color2,
                             self.forma, self.anchoLinea)
            texto = fuente.render(self.texto, True, (255, 255, 255))
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))

    def pintar(self):
        if self.forma.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(self.superficie, colorBotones1,
                             self.forma, self.anchoLinea)
            texto = fuente.render(self.texto, True, colorTexto)
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))
        else:
            pygame.draw.rect(self.superficie, colorBotones2,
                             self.forma, self.anchoLinea)
            texto = fuente.render(self.texto, True, colorTexto)
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))

    def getForma(self):
        return self.forma

    def vectoresBTN(self):
        imagen = pygame.image.load(self.directorio)
        imagen = pygame.transform.scale(imagen, self.scaleImagen)
        screen.blit(imagen, self.posImagen)

    def radioButton(self, condicion):
        pygame.draw.rect(self.superficie, colorBotones1,
                         self.forma, self.anchoLinea)
        if condicion < 0:
            pygame.draw.circle(self.superficie, (0, 0, 0),
                               (self.forma[0] + self.forma[2] / 2,
                                self.forma[1] + self.forma[2] / 2),
                               self.forma[2] / 2)


# -------------------------------------------------- VARIABLES IMPORTANTES-----------------------------------------------
mostrar_listas = 1# Variable para interfaz de listas de reproduccion

mostrar_radiobutton = 1# Variable para mostrarlo

texto_input = ''# Variable para el texto de entrada de la lista de reproduccion

# Variable para los caracteres permitidos de lista de reproduccion
caract = '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ñ', 'z', 'x', 'c', 'v', 'b', 'n', 'm'

# Variable para el texto de lista de reproduccion
texto_nombreLista = 'Introduzca el nombre de la lista de reproduccion: '

activar_ventana_edicion = 1# Activa la ventana para editar canciones de una lista

mostrar_msgpl = 1# Variable del mensaje que indica que la playlist ya esta creada

CambiarFondo = 1# Variable para cambiar el color del fondo

imagenCancion = False# Variabe para saber si una cancion tiene imagen asociada

mostrar_eliminar = 1# Permite mostrar el mensaje de que no se puede borrar la lista actual

imagen_asociada = False# Variable para asociar imagen a una cancion

cancionCargada = False# Saber si se subió una canción

activaNombreCanciones = 1# Permite saber cuando se colocan los nombres en pantalla

playlist_cargada = False# Control de reproducción

lista = 1# Activa opciones de listas

canciones = 'Canciones Añadidas'# Carpeta donde se guardan las listas por defecto

estado_cancion = ''# Muy importante, controla todo el comportamiento de la canción

ruta = ''  # Variable que establece el directorio de la lista de reproduccion actual

Avanzar = 4  # Variable que representa el limite maximo del indice de cancion que se va a imprimir en pantalla

Avanzar1 = 0  # Variable que representa el limite minimo del indice de cancion que se va a imprimir en pantalla

ayuda_mostrar = 1  # Variable para mostrar la ventana de ayuda

numAyuda = 0  # Variable que permite avanzar en la ventana de ayuda

fondoCambiado = False  # Variable para saber si se cambio el fondo

colorFondo = ''  # Variable para el cambio de color

# Colores predeterminados de los botones y el texto
colorBotones1 = (64, 128, 128)
colorBotones2 = (46, 90, 90)
colorTexto = (255, 255, 255)
# --------------------------------FIGURAS, BOTONES, TEXTOS Y ANIMACIONES------------------------------------------------
# Boton de ayuda
btnAyuda = boton('Ayuda', pygame.Rect(370, 50, 100, 50),
                 (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0)

# Boton para ver las paginas de ayuda
btnAvPag = boton('', pygame.Rect(1200, 200, 50, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0,
                 'botones/Avanzar.png', (50, 50), (1200, 200))
btnRePag = boton('', pygame.Rect(1100, 200, 50, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0,
                 'botones/Retroceder.png', (50, 50), (1100, 200))

# Boton para cerrar ventana de ayuda
btnCerrarAyuda = boton('cerrar', pygame.Rect(1150, 600, 80, 60), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen,
                       0)
# Boton para salir del programa
btnSalir = boton('Salir', pygame.Rect(610, 50, 100, 50),
                 (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0)
# Botón para activar las opciones de listas de reproducción
btnOpcionesListas = boton('Opciones Lista de Reproducción', pygame.Rect(50, 50, 300, 50), colorBotones1, colorBotones2,
                          (255, 255, 255), screen, 0)
# Botones para las listas de reproducción
btnEditarLista = boton('Editar Lista', pygame.Rect(50, 120, 170, 50), (64, 128, 128), (46, 90, 90),
                       (255, 255, 255), screen, 0)
btnCargarListas = boton('Cargar Lista', pygame.Rect(240, 120, 170, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255),
                        screen, 0)
btnCrearListas = boton('Crear Lista Nueva', pygame.Rect(430, 120, 170, 50), (64, 128, 128), (46, 90, 90),
                       (255, 255, 255), screen, 0)
btnAlmacenarListas = boton('Almacenar Lista', pygame.Rect(620, 120, 170, 50), (64, 128, 128), (46, 90, 90),
                           (255, 255, 255), screen, 0)
btnEliminarListas = boton('Eliminar Lista', pygame.Rect(810, 120, 170, 50), (64, 128, 128), (46, 90, 90),
                          (255, 255, 255), screen, 0)
btnContinuarEliminar = boton('Continuar', pygame.Rect(460, 280, 80, 30), (60, 120, 120), (46, 90, 90), (255, 255, 255),
                             screen, 0)

# Botón para cambiar el color del fondo
btnCambiarFondo = boton('Fondo', pygame.Rect(490, 50, 100, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen,
                        0)

btnCerrarFondo = boton('Cerrar', pygame.Rect(930, 550, 100, 50), (60, 120, 120), (46, 90, 90), (255, 255, 255), screen,
                       0)

# Botones para los colores del fondo

btnNaranja = boton('Naranja', pygame.Rect(100, 100, 100, 50), (239, 228, 176), (249, 244, 223), (255, 255, 255), screen,
                   0, color=(255, 159, 96), color2=(255, 127, 39))

btnRojo = boton('Rojo', pygame.Rect(100, 170, 100, 50), (239, 228, 176), (249, 244, 223), (255, 255, 255), screen, 0,
                color=(187, 0, 28), color2=(136, 0, 21))

btnAzul = boton('Azul', pygame.Rect(100, 240, 100, 50), (239, 228, 176), (249, 244, 223), (255, 255, 255), screen, 0,
                color=(30, 195, 232), color2=(19, 64, 183))

btnNegro = boton('Negro', pygame.Rect(100, 310, 100, 50), (239, 228, 176), (249, 244, 223), (255, 255, 255), screen, 0,
                 color=(75, 75, 75), color2=(23, 31, 60))

btnPredeterminado = boton('Predeterminado', pygame.Rect(100, 380, 140, 50), (60, 120, 120), (46, 90, 90),
                          (255, 255, 255), screen, 0, color=(64, 128, 128), color2=(46, 90, 90))
# Marco donde se muestran las canciones
marcoCanciones = boton('', pygame.Rect(790, 190, 320, 310),
                       (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 10)

# Botones básicos para el control de la música
btnPause = boton('', pygame.Rect(550, 650, 50, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0,
                 'botones/btnPause.png', (50, 50), (550, 650))
btnPlay = boton('', pygame.Rect(710, 650, 50, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0,
                'botones/btnPlay.png', (50, 50), (710, 650))
btnForward = boton('', pygame.Rect(790, 650, 50, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0,
                   'botones/btnForward.png', (50, 50), (790, 650))
btnRewind = boton('', pygame.Rect(470, 650, 50, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0,
                  'botones/btnRewind.png', (50, 50), (470, 650))
btnStop = boton('', pygame.Rect(630, 650, 50, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0,
                'botones/btnStop.png', (50, 50), (630, 650))

# Opciones de crear lista de reproducción
btnCrearpl = boton('Crear Lista', pygame.Rect(800, 450, 250, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen,
                   0)
btnCerrar = boton('Cerrar', pygame.Rect(510, 450, 250, 50),
                  (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0)

# Botón para no volver a mostrar el mensaje sobre asociar una imagen a la canción
radiobutton_imagen = boton('', pygame.Rect(
    380, 270, 20, 20), (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0)

# Opciones para la edición de las listas de reproducción
btn_añadir_cancion = boton('Añadir', pygame.Rect(20, 200, 100, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255),
                           screen, 0)

btn_eliminar_cancion = boton('Eliminar', pygame.Rect(220, 200, 100, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255),
                             screen, 0)

# Botones asociados a la ventana de agregar una imagen
Imagen = boton('', pygame.Rect(50, 100, 500, 200), (46, 90, 90),
               (46, 90, 90), (255, 255, 255), screen, 0)
ImagenSi = boton('Si', pygame.Rect(140, 200, 50, 20),
                 (50, 114, 109), (41, 96, 90), (255, 255, 255), screen, 0)
ImagenNo = boton('No', pygame.Rect(290, 200, 50, 20),
                 (50, 114, 109), (41, 96, 90), (255, 255, 255), screen, 0)
MismoArchivo = boton('La cancion ya esta en la playlist', pygame.Rect(200, 300, 400, 200), (64, 128, 128), (46, 90, 90),
                     (255, 255, 255), screen, 0)
ContinuarMensajeArchivo = boton('continuar', pygame.Rect(200, 350, 200, 75), (64, 128, 128), (46, 90, 90),
                                (255, 255, 255), screen, 0)

# Mensaje por si quiere crear una lista que ya existe
MensajePlaylist = boton('Ya existe una Lista de Reproduccion con ese nombre', pygame.Rect(300, 150, 600, 40),
                        (64, 128, 128), (46, 90, 90), (255, 255, 255), screen, 0)
ContinuarMensajePlaylist = boton('continuar', pygame.Rect(300, 250, 600, 40), (64, 128, 128), (46, 90, 90),
                                 (255, 255, 255), screen, 0)

# Carpeta para la playlist sin guardar
playlist_sin_guardar = 'Playlist'
if not os.path.exists(playlist_sin_guardar):
    os.mkdir(playlist_sin_guardar)

if not os.path.exists(canciones):
    os.mkdir(canciones)

if not os.path.exists('imagenes_Asociadas'):
    os.mkdir('imagenes_Asociadas')

cancionActual = 0
reproduciendo_lista = False

# -------------------------------------------------------------Ventana Emergente---------------------------------------------------------------------
# Identificar en que sistema se está trabajando y abrir el directorio principal de acuerdo al  sistema
if sys.platform.startswith('win32'):
    # os.system('start .')
    directorio_principal = os.environ['USERPROFILE']
elif sys.platform.startswith('linux'):
    # os.system('xdg-open .')
    directorio_principal = os.environ['HOME']

guardar_directorio_inicial = directorio_principal

lista_archivos_totales = os.listdir(path=directorio_principal)

btn_aceptar_Archivo = boton('Aceptar', pygame.Rect(450, 650, 100, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255),
                            screen, 0)
btn_cancelar_Archivo = boton('Cancelar', pygame.Rect(320, 650, 100, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255),
                             screen, 0)
btn_anterior_directorio = boton('Atrás', pygame.Rect(200, 650, 100, 50), (64, 128, 128), (46, 90, 90), (255, 255, 255),
                                screen, 0)

y_archivo = 20
x_archivo = 20

ventanaCanciones = pygame.Surface((600, 800))
ventana_dialogo_archivos = 1

# Variables para el control de extensión soportada
archivo_permitido = ['.mp3', '.wav', '.png', '.jpg', '.bmp', '.ogg']
archivo_audio_permitido = ['.mp3', '.wav', '.ogg']
todos_permitidos = False


carpeta_principal = [files for files in lista_archivos_totales if
                     os.path.isfile(os.path.join(directorio_principal, files)) and (
                             files[-4:] in archivo_permitido) or os.path.isdir(
                         os.path.join(directorio_principal, files))]

texto_archivo = ''
archivo_seleccionado = False

cancion_subida = False
play_subida = False

añadir_cancion = False

Buscar = ''

imagen_subida = False

ruta_imagenes = os.getcwd() + '/imagenes_Asociadas'

nombre_archivo_seleccionado = ''

tiempo_inicial_clic = 0
tiempo_espera_dobleClic = 250
# ------------------------------------------Barra volumen------------------------------------------------
barraVolumen = pygame.image.load("botones/barraVolumen.png").convert_alpha()
x_indicador = 199
y_indicador = 610
pos_indicador = (x_indicador, y_indicador)  # Posición inicial del indicador
ancho = 878
alto = 4
radio = 2
# Coordenadas del centro del botón
centro = (x_indicador + ancho // 2, y_indicador + alto // 2)
# Longitud de la barra (sin contar los extremos del botón)
longitud_barra = ancho - radio * 2
barra = pygame.Rect(x_indicador + radio, y_indicador +
                    alto // 2 - 2, longitud_barra, 4)
mostrar_volumen = False
porcentaje_volumen = 0

directorio_canciones = None
deshabilitar_botones = False

# -----------------------------------------------Ciclo para el proceso--------------------------------------------------
while running:
# -------------------------------- Acá se colocan todos los eventos que se vayan a realizar-----------------------------
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        if barra.collidepoint(pygame.mouse.get_pos()):
            # Detecta la posición del mouse
            pos_mouse = pygame.mouse.get_pos()

            # Limita la posición del mouse a la barra
            pos_mouse = (min(x_indicador + longitud_barra,
                             max(x_indicador, pos_mouse[0])), y_indicador + alto // 2)
            # Calcula el porcentaje de volumen
            porcentaje_volumen = int(
                (pos_mouse[0] - x_indicador) / longitud_barra * 100)
            # Actualiza la posición del indicador
            pos_indicador = (pos_mouse[0] - radio, y_indicador)
            volumen = porcentaje_volumen / 100.0
            pygame.mixer.music.set_volume(volumen)
            mostrar_volumen = True

        # Evento para detectar clic del mouse
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = pygame.mouse.get_pos()  # Detectar la posición del mouse
            
            if btnSalir.getForma().collidepoint(pos):
                running = False
                
            if ventana_dialogo_archivos < 0:
                y_archivo = 20  # Posicion inicial del archivo
                x_archivo = 20  # Posicion inicial del archivo

                # Toma cada archivo de las lista
                for numeroArchivo, file in enumerate(carpeta_principal):

                    if y_archivo > 600:  # Para evitar salir de la pantalla
                        x_archivo += 300
                        y_archivo = 20
                    btnArchivo = pygame.Rect(x_archivo, y_archivo, 200, 20)
                    y_archivo += 30

                    # Boton para cuando lo seleccionado es una carpeta
                    if btnArchivo.collidepoint(pos):

                        nombre_archivo_seleccionado = file
                        if os.path.isdir(os.path.join(directorio_principal, file)):
                            ventanaCanciones.fill((0, 0, 0))
                            directorio_principal = directorio_principal + '/' + file
                            lista_archivos_totales = os.listdir(
                                path=directorio_principal)

                            # Carpeta donde está todo lo que se muesta en pantalla
                            carpeta_principal = [files for files in lista_archivos_totales if
                                                 os.path.isfile(os.path.join(directorio_principal, files)) and (
                                                         files[-4:] in archivo_permitido) or os.path.isdir(
                                                     os.path.join(directorio_principal, files))]

                            # Ruta del directorio
                            ruta_archivo = directorio_principal
                            archivo_seleccionado = True

                        # Boton para cuando lo seleccionado es un archivo
                        if os.path.isfile(os.path.join(directorio_principal, file)) and Buscar == 'canción':
                            # Ruta de la canción
                            cancionAñadida = directorio_principal + '/' + nombre_archivo_seleccionado

                        if os.path.isfile(os.path.join(directorio_principal, file)) and Buscar == 'imagen':
                            dir_imagen = directorio_principal + '/' + nombre_archivo_seleccionado

            # Evento del boton para mostrar los archivos en el directorio anterior
            if btn_anterior_directorio.getForma().collidepoint(
                    pos) and directorio_principal != guardar_directorio_inicial and ventana_dialogo_archivos < 0:
                ventanaCanciones.fill((0, 0, 0))
                directorio_principal = os.path.dirname(directorio_principal)
                lista_archivos_totales = os.listdir(path=directorio_principal)
                carpeta_principal = [files for files in lista_archivos_totales if
                                     os.path.isfile(os.path.join(directorio_principal, files)) and (
                                             files[-4:] in archivo_permitido) or os.path.isdir(
                                         os.path.join(directorio_principal, files))]

            # Para cargar el archivo, una accion diferente para cuando es un archivo o directorio
            if btn_aceptar_Archivo.getForma().collidepoint(pos) and ventana_dialogo_archivos < 0 and archivo_seleccionado !='':

                if Buscar == 'eliminar directorio' and nombre_archivo_seleccionado != '':
                    shutil.rmtree(directorio_principal)
                    ventana_dialogo_archivos *= -1

                if Buscar == 'Almacenar directorio':
                    directorio = os.path.abspath(directorio_principal)
                    nombreDirectorio = os.path.basename(os.path.normpath(ruta))
                    directorio_origen = directorio + '/' + nombreDirectorio
                    try:
                        shutil.copytree(ruta, directorio_origen)
                    except:
                        pass
                    ventana_dialogo_archivos *= -1

                if nombre_archivo_seleccionado != '' and nombre_archivo_seleccionado[
                                                         -4:] in archivo_audio_permitido and Buscar == 'canción' or Buscar == 'eliminar canción':

                    cancionAñadida = directorio_principal + '/' + nombre_archivo_seleccionado
                    if Buscar == 'canción':
                        cancion_subida = True

                        # Cuando se da clic en el botón de aceptar de la ventana de archivos, se añade la canción
                        if cancion_subida == True:
                            dir_path = os.path.dirname(cancionAñadida)
                            verificaArchivo = ruta + dir_path
                            # Validación por si existe ya en la lista
                            if not os.path.exists(verificaArchivo):
                                try:
                                    shutil.copy(cancionAñadida, ruta)
                                except shutil.SameFileError:
                                    pass
                                activaNombreCanciones *= -1
                        if mostrar_radiobutton > 0:
                            imagen_asociada = True  # Activa la ventana para solicitar una imagen
                    elif Buscar == 'eliminar canción':
                        ventanaCanciones.fill((0,0,0))
                        os.remove(cancionAñadida)

                        lista_archivos_totales = os.listdir(path=directorio_principal)
                        carpeta_principal = [files for files in lista_archivos_totales if
                                             os.path.isfile(os.path.join(directorio_principal, files)) and (
                                                     files[-4:] in archivo_permitido) or os.path.isdir(
                                                 os.path.join(directorio_principal, files))]
                        pygame.mixer.music.stop()
                        estado_cancion = 'detenida'

                    ventana_dialogo_archivos *= -1
                    pygame.display.update()
                if nombre_archivo_seleccionado != '' and Buscar == 'imagen':
                    nombre_imagen = os.path.basename(cancionAñadida)[
                                    :-4] + nombre_archivo_seleccionado[-4:]
                    nuevo_directorio_imagen = os.getcwd() + '/imagenes_Asociadas/' + nombre_imagen
                    # Valida si la imagen está ya asociada
                    if not os.path.exists(nuevo_directorio_imagen):
                        try:
                            shutil.copy(dir_imagen, nuevo_directorio_imagen)
                            os.rename(dir_imagen, nuevo_directorio_imagen)
                        except:
                            pass
                    ventana_dialogo_archivos *= -1
                if nombre_archivo_seleccionado != '' and os.path.isdir(
                        directorio_principal) and Buscar == 'directorio':
                    for file in carpeta_principal:
                        if file[-4:] in archivo_audio_permitido:
                            todos_permitidos = True
                        else:
                            todos_permitidos = False
                            break
                    if todos_permitidos == True or not os.listdir(directorio_principal):
                        buscador_playlist = directorio_principal
                        play_subida = True
                        directorio_canciones = directorio_principal
                        ventana_dialogo_archivos *= -1
                nombre_archivo_seleccionado = ''
            if btn_cancelar_Archivo.getForma().collidepoint(pos) and ventana_dialogo_archivos < 0:
                ventana_dialogo_archivos *= -1

            if radiobutton_imagen.getForma().collidepoint(pos):
                mostrar_radiobutton *= -1
            # Activa las opciones para las listas de reproducción
            if btnOpcionesListas.getForma().collidepoint(
                    pos) and mostrar_listas > 0 and ventana_dialogo_archivos > 0 and CambiarFondo > 0:
                lista *= -1
                if activar_ventana_edicion < 0:
                    activar_ventana_edicion *= -1

            if btnEditarLista.getForma().collidepoint(
                    pos) and lista < 0 and mostrar_eliminar > 0 and ventana_dialogo_archivos > 0 and CambiarFondo > 0:
                activar_ventana_edicion *= -1

                # Evento para botón de añadir una canción a la lista
            if btn_añadir_cancion.getForma().collidepoint(pos) and activar_ventana_edicion < 0 and imagen_asociada == False:
                # Elije una canción para cargar a la lista cargada
                Buscar = 'canción'
                ventana_dialogo_archivos *= -1
                # Para copiar la canción a la lista
                añadir_cancion = True

            if btn_eliminar_cancion.getForma().collidepoint(
                    pos) and activar_ventana_edicion < 1 and ventana_dialogo_archivos > 0 and imagen_asociada == False:
                Buscar = 'eliminar canción'
                ventana_dialogo_archivos *= -1

            # Evento para cargar una nueva lista
            if btnCargarListas.getForma().collidepoint(
                    pos) and activar_ventana_edicion > 0 and mostrar_listas > 0 and mostrar_eliminar > 0 and ayuda_mostrar > 0 and ventana_dialogo_archivos > 0 and CambiarFondo > 0:
                Buscar = 'directorio'
                ventana_dialogo_archivos *= -1

            # Eventos para crear una nueva lista
            if btnCrearListas.getForma().collidepoint(
                    pos) and lista < 0 and activar_ventana_edicion > 0 and mostrar_listas > 0 and mostrar_eliminar > 0 and ayuda_mostrar > 0 and CambiarFondo > 0 and ventana_dialogo_archivos > 0:
                mostrar_listas *= -1

            if btnCerrar.getForma().collidepoint(pos) and mostrar_listas < 0:
                mostrar_listas *= -1
                texto_input = ''

            if btnCrearpl.getForma().collidepoint(pos) and len(
                    texto_input) > 0 and mostrar_listas < 0 and ayuda_mostrar > 0:
                mostrar_listas *= -1
                directorio_principal = f'{os.getcwd()}/Playlist/{texto_input}'

                if not os.path.exists('Playlist/' + texto_input):
                    archivo = os.mkdir('Playlist/' + texto_input)
                    playlist_cargada = True
                    playlist_actual = os.listdir(archivo)
                    ruta = os.path.abspath('Playlist/' + texto_input)
                    Crearpl = True
                    playlist_actual = os.listdir(ruta)
                else:
                    mostrar_msgpl *= -1

                for file in carpeta_principal:
                    if file[-4:] in archivo_audio_permitido:
                        todos_permitidos = True
                    else:
                        todos_permitidos = False
                        break
                if todos_permitidos == True or not os.listdir(directorio_principal):
                    buscador_playlist = directorio_principal
                    play_subida = True
                    lista_archivos_totales = os.listdir(path=directorio_principal)
                    carpeta_principal = [files for files in lista_archivos_totales if
                                         os.path.isfile(os.path.join(directorio_principal, files)) and (
                                                 files[-4:] in archivo_permitido) or os.path.isdir(
                                             os.path.join(directorio_principal, files))]
                    directorio_canciones = directorio_principal

            # Evento para almacenar una lista
            if btnAlmacenarListas.getForma().collidepoint(
                    pos) and playlist_cargada == True and activar_ventana_edicion > 0 and mostrar_listas > 0 and lista < 0 and mostrar_eliminar > 0 and ayuda_mostrar > 0 and CambiarFondo > 0 and ventana_dialogo_archivos > 0:
                Buscar = 'Almacenar directorio'
                ventana_dialogo_archivos *= -1

            if ContinuarMensajePlaylist.getForma().collidepoint(pos) and lista < 0:
                mostrar_msgpl *= -1

            # Evento para eliminar una lista de reproducción
            if btnEliminarListas.getForma().collidepoint(
                    pos) and lista < 0 and activar_ventana_edicion > 0 and mostrar_listas > 0 and mostrar_eliminar > 0 and ayuda_mostrar > 0 and ventana_dialogo_archivos > 0 and CambiarFondo > 0:
                Buscar = 'eliminar directorio'
                ventana_dialogo_archivos *= -1

            if btnContinuarEliminar.getForma().collidepoint(pos):
                mostrar_eliminar *= -1

            if btnCambiarFondo.getForma().collidepoint(
                    pos) and ayuda_mostrar > 0 and mostrar_listas > 0 and mostrar_eliminar > 0 and activar_ventana_edicion > 0 and ventana_dialogo_archivos > 0 and CambiarFondo > 0:
                CambiarFondo *= -1

            if btnCerrarFondo.getForma().collidepoint(
                    pos) and ayuda_mostrar > 0 and mostrar_listas > 0 and mostrar_eliminar > 0 and activar_ventana_edicion > 0 and ventana_dialogo_archivos > 0 and CambiarFondo < 0:
                CambiarFondo *= -1

            if btnNaranja.getForma().collidepoint(pos) and CambiarFondo < 0:
                fondoCambiado = True
                colorFondo = 'Naranja'

            if btnRojo.getForma().collidepoint(pos) and CambiarFondo < 0:
                fondoCambiado = True
                colorFondo = 'Rojo'

            if btnAzul.getForma().collidepoint(pos) and CambiarFondo < 0:
                fondoCambiado = True
                colorFondo = 'Azul'

            if btnNegro.getForma().collidepoint(pos) and CambiarFondo < 0:
                fondoCambiado = True
                colorFondo = 'Negro'

            if btnPredeterminado.getForma().collidepoint(pos) and CambiarFondo < 0:
                fondoCambiado = False
                colorBotones1 = (64, 128, 128)
                colorBotones2 = (46, 90, 90)
                colorTexto = (255, 255, 255)

            if play_subida:
                ruta = os.path.abspath(buscador_playlist)
                playlist_actual = os.listdir(ruta)
                playlist_cargada = True
                # for Cancion in playlist_actual:
                #     # Agrega las canciones a la cola
                #     pygame.mixer.music.queue(os.path.join(ruta, Cancion))

            # Evento por si el usuario quiere asociar una imagen a la canción
            if ImagenSi.getForma().collidepoint(pos) and imagen_asociada == True:
                Buscar = 'imagen'
                buscarImagen = True
                imagen_asociada = False
                ventana_dialogo_archivos *= -1

            # Acción para cuando el usuario no quiere asociar imagen
            if ImagenNo.getForma().collidepoint(pos) and imagen_asociada == True:
                imagen_asociada = False

# ------------------------ Botones básicos para el control de las canciones---------------------------------------------
            if btnPlay.getForma().collidepoint(
                    pos) and playlist_cargada == True and ayuda_mostrar > 0 and CambiarFondo > 0 and not deshabilitar_botones:
                if estado_cancion == 'pausa':
                    estado_cancion = 'reanudar'

                else:
                    estado_cancion = 'reproduciendo'
                    pygame.mixer.music.load(os.path.join(
                        ruta, playlist_actual[cancionActual]))
                    pygame.mixer.music.play()
                reproduciendo_lista = True

            if btnPause.getForma().collidepoint(pos) and ayuda_mostrar > 0 and CambiarFondo > 0 and not deshabilitar_botones:
                pygame.mixer.music.pause()
                estado_cancion = 'pausa'

            if btnForward.getForma().collidepoint(pos) and CambiarFondo > 0 and not deshabilitar_botones:
                if cancionActual < (len(playlist_actual) - 1):
                    cancionActual += 1
                elif cancionActual == len(playlist_actual) - 1:
                    cancionActual = 0

                pygame.mixer.music.load(os.path.join(
                    ruta, playlist_actual[cancionActual]))
                pygame.mixer.music.play()

            if btnStop.getForma().collidepoint(pos) and CambiarFondo > 0 and not deshabilitar_botones:
                pygame.mixer.music.stop()
                estado_cancion = 'detenida'

            if btnRewind.getForma().collidepoint(pos) and estado_cancion == 'reproduciendo' and CambiarFondo > 0 and not deshabilitar_botones:
                time_actual = pygame.time.get_ticks()
                if time_actual - tiempo_inicial_clic > tiempo_espera_dobleClic:
                    pygame.mixer.music.play()

                elif time_actual - tiempo_inicial_clic < tiempo_espera_dobleClic:
                    if cancionActual > (-(len(playlist_actual) - 1)):
                        cancionActual -= 1
                    elif cancionActual == -(len(playlist_actual) - 1):
                        cancionActual += 1
                    pygame.mixer.music.stop()
                    pygame.mixer.music.load(os.path.join(
                        ruta, playlist_actual[cancionActual]))
                    pygame.mixer.music.play()

                tiempo_inicial_clic = time_actual
            # -----------------------------------------------------------------------------------------------------------------------

            if btnAyuda.getForma().collidepoint(
                    pos) and ayuda_mostrar > 0 and mostrar_listas > 0 and mostrar_eliminar > 0 and activar_ventana_edicion > 0 and ventana_dialogo_archivos > 0 and CambiarFondo > 0:
                ayuda_mostrar *= -1

            if btnAvPag.getForma().collidepoint(pos):
                numAyuda += 1
                if numAyuda > 2:
                    numAyuda = 2

            if btnRePag.getForma().collidepoint(pos):
                numAyuda -= 1
                if numAyuda < 0:
                    numAyuda = 0

            if btnCerrarAyuda.getForma().collidepoint(pos) and ayuda_mostrar < 0:
                ayuda_mostrar *= -1

            # Para avanzar o retroceder en la lista cargada
            if playlist_cargada == True:
                y = 200
                btnAvanzar = pygame.Rect(980, 520, 50, 50)
                btnRetroceder = pygame.Rect(910, 520, 50, 50)
                if btnAvanzar.collidepoint(pos) and ayuda_mostrar > 0:
                    Avanzar += 4
                    Avanzar1 += 4
                if btnRetroceder.collidepoint(pos) and ayuda_mostrar > 0:
                    Avanzar -= 4
                    Avanzar1 -= 4
                if Avanzar <= 4:
                    Avanzar = 4
                    Avanzar1 = 0
                if Avanzar - 4 > len(playlist_actual):
                    Avanzar -= 4
                    Avanzar1 -= 4
                for numeroBoton, nombreCancion in enumerate(playlist_actual):
                    if Avanzar1 <= numeroBoton < Avanzar:
                        btnCancion = pygame.Rect(800, y, 300, 50)
                        y += 80
                        if btnCancion.collidepoint(pos) and ayuda_mostrar > 0 and CambiarFondo > 0:
                            cancionCargada = True
                            imagenAsociada = os.getcwd() + '/imagenes_Asociadas/'
                            pygame.mixer.music.stop()
                            cancionActual = numeroBoton
                            pygame.mixer.music.load(
                                os.path.join(
                                    ruta, playlist_actual[cancionActual]))
                            pygame.mixer.music.play()
                            reproduciendo_lista = True
                            estado_cancion = 'reproduciendo'

        # Evento para entrada de texto
        if event.type == pygame.KEYDOWN and mostrar_listas < 0:
            tamaño = len(texto_input)
            if pygame.key.name(event.key) == 'backspace':
                tamaño = len(texto_input)
                if tamaño > 0:
                    texto_input = texto_input[:tamaño - 1]
            else:
                # Restringe los caracteres prohibidos
                for x in caract:
                    if pygame.key.name(
                            event.key) == x and not pygame.key.get_mods() & pygame.K_LCTRL and not pygame.key.get_mods() & pygame.K_RSHIFT and not pygame.key.get_mods() & pygame.KMOD_RSHIFT:
                        texto_input += event.unicode

    # ----------------------- ---------------RENDER YOUR GAME HERE------------------------------------------------------

    if fondoCambiado == False:
        screen.blit(fondo, (0, 0))
    else:
        if colorFondo == 'Naranja':
            screen.fill((255, 127, 39))
            colorBotones1 = (89, 89, 255)
            colorBotones2 = (30, 72, 240)
            colorTexto = ((255, 255, 255))
        if colorFondo == 'Rojo':
            screen.fill((136, 0, 21))
            colorBotones1 = ((50, 50, 50))
            colorBotones2 = ((0, 0, 0))
            colorTexto = ((255, 255, 255))
        if colorFondo == 'Azul':
            screen.fill((19, 64, 183))
            colorBotones1 = ((205, 205, 205))
            colorBotones2 = ((255, 255, 255))
            colorTexto = ((0, 0, 0))
        if colorFondo == 'Negro':
            screen.fill((0, 0, 0))
            colorBotones1 = ((205, 205, 205))
            colorBotones2 = ((255, 255, 255))
            colorTexto = ((0, 0, 0))
    # Coloca en pantalla la imagen asociada a la canción, únicamente si está asociada
    if os.listdir(directorio_canciones) and estado_cancion == 'reproduciendo' or estado_cancion == 'pausa' or estado_cancion == 'reanudar':
        for imagen in os.listdir(path=ruta_imagenes):
            if os.listdir(directorio_canciones) and imagen[:-4] == (playlist_actual[cancionActual][:-4]):
                imagen_colocar = pygame.image.load(ruta_imagenes + '/' + imagen)
                imagen_colocar = pygame.transform.scale(imagen_colocar, (380, 380))
                screen.blit(imagen_colocar, (60, 180))
        display_nombre_cancion = fuente.render('Reproduciendo...'+playlist_actual[cancionActual],
                                       True,
                                       (255, 255, 255))
        screen.blit(display_nombre_cancion, (500,550))

    # Ventana para la edición de las listas de reproducción
    if activar_ventana_edicion < 0:
        btn_añadir_cancion.pintar()
        btn_eliminar_cancion.pintar()

    if pygame.mouse.get_pressed()[0]:
        x, y = pygame.mouse.get_pos()

    # Botones básicos del inicio
    btnOpcionesListas.pintar()
    btnAyuda.pintar()
    btnCambiarFondo.pintar()
    btnSalir.pintar()

    # Si se presiona el botón que activa las opciones
    if lista < 0:
        btnAlmacenarListas.pintar()
        btnCargarListas.pintar()
        btnCrearListas.pintar()
        btnEditarLista.pintar()
        btnEliminarListas.pintar()

    # Se encarga de mostrar las canciones, y botones cuando se carga una playlist
    if playlist_cargada == True and os.listdir(directorio_canciones):

        marcoCanciones.pintar()  # Marco donde se colacan las canciones
        y = 200  # Posición inicial de las canciones en el marco

        # Permite crear botones para cada una de las canciones en el directorio cargado
        for numeroBoton, nombreCancion in enumerate(playlist_actual):
            pygame.draw.rect(screen, (200, 200, 200), btnAvanzar)
            pygame.draw.rect(screen, (200, 200, 200), btnRetroceder)
            imagen_avanzar = pygame.image.load('botones/Avanzar.png')
            imagen_avanzar = pygame.transform.scale(imagen_avanzar, (50, 50))
            imagen_retroceder = pygame.image.load('botones/Retroceder.png')
            imagen_retroceder = pygame.transform.scale(
                imagen_retroceder, (50, 50))
            screen.blit(imagen_avanzar, btnAvanzar)
            screen.blit(imagen_retroceder, btnRetroceder)
            if Avanzar1 <= numeroBoton < Avanzar:
                nombreCancion = nombreCancion[:-4]
                texto = fuente.render(nombreCancion, True, (0, 0, 0))

                # Boton de cada cancion
                btnCancion = pygame.Rect(800, y, 300, 50)
                pygame.draw.rect(screen, (200, 200, 200), btnCancion)
                btnNombreCancion = texto.get_rect()  # Colocar nombre de cada canción en un botón
                btnNombreCancion.center = btnCancion.center  # Centra el texto
                screen.blit(texto, btnNombreCancion)
                y += 80  # Para dejar un espacio de separación en cada botón

        # Dibuja los botones para las acciones de las canciones
        btnForward.vectoresBTN()
        btnRewind.vectoresBTN()
        btnStop.vectoresBTN()
        btnPause.vectoresBTN()
        btnPlay.vectoresBTN()

        # Barra de volumen
        pygame.draw.rect(barraVolumen, (0, 0, 0), barra)
        screen.blit(barraVolumen, (150, 520))
        texto_volumen = fuente.render(
            f'Volumen: {porcentaje_volumen}%', True, (255, 255, 255))
        screen.blit(texto_volumen, (1140, 590))
        indicador = pygame.draw.circle(screen, (0, 0, 0), pos_indicador, 10)
        deshabilitar_botones = False

    else:
        deshabilitar_botones = True

    if mostrar_eliminar < 0:
        error_eliminar = pygame.Rect(230, 250, 545, 70)
        pygame.draw.rect(screen, (64, 128, 128), error_eliminar, 0)
        texto_eliminar = fuente.render('No se puede eliminar la lista de reproducción cargada actualmente', True,
                                       (255, 255, 255))
        screen.blit(texto_eliminar, error_eliminar)
        btnContinuarEliminar.pintar()

    # Para el boton de ayuda
    if ayuda_mostrar < 0:
        imagenAyuda = os.listdir('botones/Ayuda')
        ayuda_img = pygame.image.load('botones/Ayuda/' + imagenAyuda[numAyuda])
        ayuda_img = pygame.transform.scale(ayuda_img, (1042, 709))
        screen.blit(ayuda_img, (5, 5))
        btnAvPag.vectoresBTN()
        btnRePag.vectoresBTN()
        btnCerrarAyuda.pintar()

    # Para asociar una imagen a cada canción
    if imagen_asociada == True:
        Imagen.pintar()
        ImagenSi.pintar()
        ImagenNo.pintar()

        # if mostrar_radiobutton > 0:
        radiobutton_imagen.radioButton(mostrar_radiobutton)
        pregunta_asociar_imagen = fuente.render(
            '¿Desea asociar una imagen a la canción?', True, (255, 255, 255))
        screen.blit(pregunta_asociar_imagen, (70, 120))
        pregunta_imagen = fuente.render(
            'No volver a mostrar este mensaje', True, (255, 255, 255))
        screen.blit(pregunta_imagen, (70, 270))

    # Boton para crear una lista de reproducción
    if mostrar_listas < 0:
        lista_reproduccion.fill((75, 128, 128))
        texto_superficie = fuente.render(texto_input, True, (255, 255, 255))
        texto_nombre = fuente.render(texto_nombreLista, True, (255, 255, 255))
        lista_reproduccion.blit(texto_superficie, (50, 120))
        lista_reproduccion.blit(texto_nombre, (50, 50))
        screen.blit(lista_reproduccion, (60, 60))
        btnCerrar.pintar()
        if mostrar_msgpl > 0:
            btnCrearpl.pintar()
        elif mostrar_msgpl < 0:
            MensajePlaylist.pintar()
            ContinuarMensajePlaylist.pintar()

    # Reproduce la siguiente canción en la lista cuando termina una, excepto si la canción está pausada
    if pygame.mixer.music.get_busy() == False and reproduciendo_lista == True and os.listdir(directorio_canciones):
        if estado_cancion == 'reproduciendo':
            if cancionActual < (len(playlist_actual) - 1):
                cancionActual += 1
            elif cancionActual == len(playlist_actual)-1:
                cancionActual = 0
            pygame.mixer.music.load(os.path.join(
                ruta, playlist_actual[cancionActual]))
            pygame.mixer.music.play()
        elif estado_cancion == 'reanudar':
            pygame.mixer.music.unpause()
        
    # Botones para el cambio de tema
    if CambiarFondo < 0:
        Ventana_Cambio_Fondo = pygame.Rect(50, 50, 1000, 600)
        pygame.draw.rect(screen, (190, 200, 210), Ventana_Cambio_Fondo, 0)
        btnCerrarFondo.pintar()
        btnNaranja.pintarBotones()
        btnRojo.pintarBotones()
        btnAzul.pintarBotones()
        btnNegro.pintarBotones()
        btnPredeterminado.pintarBotones()
        pygame.display.update()

    if ventana_dialogo_archivos < 0:
        screen.blit(ventanaCanciones, (0, 0))
        y_archivo = 20
        x_archivo = 20

        for numeroArchivo, file in enumerate(carpeta_principal):# Crea un boton para cada archivo en la carpeta
            if y_archivo > 600:# Mueve las posiciones para evitar salir del rango de visión
                x_archivo += 300
                y_archivo = 20
            text = fuente.render(file, True, (0, 0, 0))
            btnArchivo = pygame.Rect(x_archivo, y_archivo, 200, 20)# Boton de cada cancion
            pygame.draw.rect(ventanaCanciones, (200, 200, 200), btnArchivo)
            numeroArchivo = file
            btnNombreArchivo = text.get_rect()  # Colocar nombre de cada canción en un botón
            btnNombreArchivo.center = btnArchivo.center  # Centra el texto
            ventanaCanciones.blit(text, btnNombreArchivo)

            y_archivo += 30
        y_archivo = 20
        # Botones principales de navegación
        btn_aceptar_Archivo.pintar()
        btn_cancelar_Archivo.pintar()
        btn_anterior_directorio.pintar()
        # Muestra en pantalla el archivo seleccionado
        if archivo_seleccionado:
            texto_archivo = fuente.render(
                'Archivo seleccionado: ' + nombre_archivo_seleccionado, True, (255, 255, 255))
            screen.blit(texto_archivo, (300, 600))

    pygame.display.update()
    pygame.display.flip()
    clock.tick(60)
pygame.quit()
