import pygame, sys, math
pygame.init()
pantalla = pygame.display.set_mode((1280,720), pygame.RESIZABLE)
barraVolumen = pygame.image.load("botones/barraVolumen.png").convert_alpha()
#indicador = pygame.image.load("indicador.jpeg").convert_alpha()
clock = pygame.time.Clock()
x = 60
y = 90

pos_indicador = (x, y)  # Posición inicial del indicador

fuente = pygame.font.SysFont('Liberation  Serif', 20)

ancho = 878
alto = 4
radio = 2
centro = (x + ancho // 2, y + alto // 2)  # Coordenadas del centro del botón
longitud_barra = ancho - radio * 2  # Longitud de la barra (sin contar los extremos del botón)
barra = pygame.Rect(x + radio, y + alto // 2 - 2, longitud_barra, 4)
mostrar_volumen = False

porcentaje_volumen = 0
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN and event.button==1:
            pygame.mixer.music.load('cancion2.mp3')
            pygame.mixer.music.play()
        
        if barra.collidepoint(pygame.mouse.get_pos()):
             # Detecta la posición del mouse
            pos_mouse = pygame.mouse.get_pos()

            # Limita la posición del mouse a la barra
            pos_mouse = (min(x + longitud_barra, max(x, pos_mouse[0])), y + alto // 2)

            # Calcula el porcentaje de volumen
            porcentaje_volumen = int((pos_mouse[0] - x) / longitud_barra * 100)
            # Actualiza la posición del indicador
            pos_indicador = (pos_mouse[0] - radio, y)

            volumen = porcentaje_volumen/100.0

            pygame.mixer.music.set_volume(volumen)

            mostrar_volumen = True
            
            
    pantalla.fill((255,255,255))    
    
    #pygame.mixer.music.play()

    # Dibuja el fondo, la barra y el indicador
    
    pygame.draw.rect(barraVolumen, (0, 0, 0), barra)
    #pantalla.blit(indicador)
    
    pantalla.blit(barraVolumen, (20, 0))
    
    
    # if mostrar_volumen == True:
    #     texto = fuente.render(str(porcentaje_volumen), True, (0,0,0))
    #     pantalla.blit(texto, (500, 10))

    texto = fuente.render(str(porcentaje_volumen), True, (0,0,0))
    pantalla.blit(texto, (500, 10))
    indicador = pygame.draw.circle(pantalla, (0,0,0), pos_indicador, 10)
    pygame.display.update()
    pygame.display.flip()
    clock.tick(60)  # limits FPS to 60
pygame.quit()
