import pygame

# Inicializar pygame
pygame.init()

# Definir las variables
variables = ['Variable 1', 'Variable 2', 'Variable 3']

# Definir el tamaño de la pantalla
screen_width = 400
screen_height = 300

# Crear la pantalla
screen = pygame.display.set_mode((screen_width, screen_height))

# Definir las propiedades de los botones
button_width = 100
button_height = 50
button_padding = 10
button_color = (255, 255, 255)
button_font = pygame.font.SysFont(None, 20)

# Definir la posición inicial de los botones
button_x = button_padding
button_y = button_padding

# Crear los botones
for variable in variables:
    # Crear un rectángulo para el botón
    button_rect = pygame.Rect(button_x, button_y, button_width, button_height)

    # Dibujar el botón en la pantalla
    pygame.draw.rect(screen, button_color, button_rect)

    # Escribir el texto del botón
    button_text = button_font.render(variable, True, (0, 0, 0))
    button_text_rect = button_text.get_rect()
    button_text_rect.center = button_rect.center
    screen.blit(button_text, button_text_rect)

    # Actualizar la posición del botón
    button_x += button_width + button_padding

# Actualizar la pantalla
pygame.display.update()

# Bucle principal del juego
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

        # Detectar eventos de clic de ratón
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            for button_index, variable in enumerate(variables):
                button_rect = pygame.Rect(
                    button_padding + (button_width + button_padding) * button_index,
                    button_padding,
                    button_width,
                    button_height
                )
                if button_rect.collidepoint(mouse_pos):
                    print(f'Se hizo clic en el botón {variable}')