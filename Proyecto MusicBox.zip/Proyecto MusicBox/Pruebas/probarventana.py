import sys, os, pygame, time
pygame.init()
class boton:
    def __init__(self, texto, forma, color, color2, colorTexto, superficie, anchoLinea, directorio=None,
                 scaleImagen=None, posImagen=None):
        self.forma = forma
        self.color = color
        self.color2 = color2
        self.colorTexto = colorTexto
        self.superficie = superficie
        self.texto = texto
        self.anchoLinea = anchoLinea
        self.directorio = directorio
        self.scaleImagen = scaleImagen
        self.posImagen = posImagen

    def pintar(self):
        if self.forma.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(self.superficie, self.color, self.forma, self.anchoLinea)
            texto = fuente.render(self.texto, True, self.colorTexto)
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))
        else:
            pygame.draw.rect(self.superficie, self.color2, self.forma, self.anchoLinea)
            texto = fuente.render(self.texto, True, self.colorTexto)
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))

    def getForma(self):
        return self.forma

    def vectoresBTN(self):
        imagen = pygame.image.load(self.directorio)
        imagen = pygame.transform.scale(imagen, self.scaleImagen)
        screen.blit(imagen, self.posImagen)

    def radioButton(self, condicion):
        pygame.draw.rect(self.superficie, self.color, self.forma, self.anchoLinea)
        if condicion < 0:
            pygame.draw.circle(self.superficie, (0, 0, 0),
                               (self.forma[0] + self.forma[2] / 2, self.forma[1] + self.forma[2] / 2),
                               self.forma[2] / 2)

clock = pygame.time.Clock()  # Control de FPS
from threading import Thread
screen = pygame.display.set_mode((800,800))
fondo = pygame.image.load('fondo.jpg').convert()
fondo = pygame.transform.scale(fondo, (1280, 720))
#screen.blit(fondo, (0, 0))

#pygame.init()
if sys.platform.startswith('win32'):
    os.system('start .')
    directorio_principal = os.environ['USERPROFILE']
elif sys.platform.startswith('linux'):
    os.system('xdg-open .')
    directorio_principal = os.environ['HOME']

print(directorio_principal)
fuente = pygame.font.SysFont('Liberation  Serif', 20)  # Colocar fuentes de texto
y = 280
lista_archivos_totales = os.listdir(path=directorio_principal)

d = 20
ventanaCanciones = pygame.Surface((600, 800))
ventana_dialogo_archivos = True
carpeta_principal = [files for files in lista_archivos_totales if os.path.isfile(os.path.join(directorio_principal, files)) and (files.endswith('.png') or files.endswith('.mp3')) or os.path.isdir(os.path.join(directorio_principal, files))]
btnAlmacenarListas = boton('', pygame.Rect(0, 0, 500, 500), (64, 128, 128), (46, 90, 90),(255, 255, 255), screen, 0)

while True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = pygame.mouse.get_pos()  # Detectar la posición del mouse
            if ventana_dialogo_archivos == False:
                for numeroBoton, file in enumerate(carpeta_principal):
                    btnArchivo = pygame.Rect(10, d, 200, 20)
                    d += 30
                    if btnArchivo.collidepoint(pos) and os.path.isdir(os.path.join(directorio_principal, file)):
                        ventanaCanciones.fill((0, 0, 0))
                        d = 20
                        directorio_principal = directorio_principal+'/'+file
                        lista_archivos_totales = os.listdir(path=directorio_principal)
                        print(directorio_principal)
                        carpeta_principal = [files for files in lista_archivos_totales if os.path.isfile(os.path.join(directorio_principal, files)) and (files.endswith('.png') or files.endswith('.mp3')) or os.path.isdir(os.path.join(directorio_principal, files))]
                        print(carpeta_principal)
                        #screen.blit(ventanaCanciones,(0,0))
                        print(f'Se hizo clic en el botón {file}')
                        ventana_dialogo_archivos = True

                        #cancion = pygame.mixer.music.load(ruta + '/' + file)
    #print(directorio_principal)
    #screen.blit(fondo, (0, 0))
    screen.blit(fondo, (0, 0))
    screen.blit(ventanaCanciones,(0,0))
    #btnAlmacenarListas.pintar()
    #ventana_dialogo_archivos = True
    if ventana_dialogo_archivos == True:
        d = 20
        # carpetas = [archivo_o_carpeta for archivo_o_carpeta in os.listdir(directorio_principal) if
        # os.path.isdir(os.path.join(directorio_principal, archivo_o_carpeta))]
        for file in carpeta_principal:
            text = fuente.render(file, True, (255, 255, 255))
            # text_rect = text.get_rect(center=(320, y))
            btnArchivo = pygame.Rect(10, d, 200, 20)  # Boton de cada cancion
            pygame.draw.rect(ventanaCanciones, (200, 200, 200), btnArchivo)
            botonarchivo = file
            btnNombreArchivo = text.get_rect()  # Colocar nombre de cada canción en un botón
            btnNombreArchivo.center = btnArchivo.center  # Centra el texto
            ventanaCanciones.blit(text, btnNombreArchivo)
            # screen.blit(text,(0,d))
            d += 30
        d = 20
        ventana_dialogo_archivos = False
    pygame.display.update()
    pygame.display.flip()
    clock.tick(60)
pygame.quit()
    #screen.blit(pantalla, (0, 0))
