import pygame
import time
import random
import os

# Setup
pygame.init()
screen = pygame.display.set_mode((1280, 720), pygame.RESIZABLE)
running = True
clock = pygame.time.Clock()
fuente = pygame.font.SysFont('Liberation  Serif', 20)  # Fuente del texto
fuente2 = pygame.font.SysFont('Liberation  Serif', 25)
fuente3 = pygame.font.SysFont('Liberation  Serif', 10)
# Lista atributos instancias
atributosProp = []
elemento = ''
# Configuracion

# Variables
tirar = False
juegoActivo = False
establecerOrden = False
actual = 1
orden = [0, 0, 0, 0]
ordenDado = {}
propiedadesInstancias = []

salirCarcelSuperficie = pygame.Surface((700, 100))
salirCarcel = False
pagarMulta = False
salirGratis = False
finalizado = False
ganadoresListos = False

uno = pygame.image.load('dados/1.png')
uno = pygame.transform.scale(uno, (100, 100))

dos = pygame.image.load('dados/2.png')
dos = pygame.transform.scale(dos, (100, 100))

tres = pygame.image.load('dados/3.png')
tres = pygame.transform.scale(tres, (100, 100))

cuatro = pygame.image.load('dados/4.png')
cuatro = pygame.transform.scale(cuatro, (100, 100))

cinco = pygame.image.load('dados/5.png')
cinco = pygame.transform.scale(cinco, (100, 100))

seis = pygame.image.load('dados/6.png')
seis = pygame.transform.scale(seis, (100, 100))

cantJugadores = False
pantallaCant = pygame.Surface((700, 300))

finalizadoSurface = pygame.Surface((700, 300))

# Imagenes para los personajes:
image_per = pygame.image.load('personajes/personaje1.jpg')
image_per = pygame.transform.scale(image_per, (50, 50))
image_per2 = pygame.image.load('personajes/tren.png')
image_per2 = pygame.transform.scale(image_per2, (50, 50))
image_per3 = pygame.image.load('personajes/barco.png')
image_per3 = pygame.transform.scale(image_per3, (50, 50))


def strToList(f1, Max, sep=[' ', ',', '', '\n', '\t'], pab='', in_f1=0, palabras=[]):
    if in_f1 == Max:
        return palabras
    elif f1[in_f1] not in sep and in_f1 == Max-1:
        return strToList(f1, Max, sep, '', in_f1 + 1, palabras + [pab+f1[in_f1]])
    elif (f1[in_f1] not in sep):
        return strToList(f1, Max, sep, pab + f1[in_f1], in_f1 + 1, palabras)

    elif f1[in_f1] in sep and f1[in_f1-1] not in sep:
        return strToList(f1, Max, sep, '', in_f1 + 1, palabras + [pab])

    else:
        return strToList(f1, Max, sep, '', in_f1 + 1, palabras)


def transpuestaAux(mat, rows, cols, resul=[], in_row=0, in_col=0, añadir=[]):
    if in_col == cols:
        return resul
    elif in_row == rows:
        return transpuestaAux(
            mat, rows, cols, resul + [añadir], in_row * 0, in_col + 1, añadir=[]
        )
    else:
        return transpuestaAux(
            mat, rows, cols, resul, in_row +
            1, in_col, añadir + [mat[in_row][in_col]]
        )


# Archivo del setup
with open('setup.txt', 'r', encoding='utf-8') as s:
    setup = s.readlines()

setup = strToList(setup[1], len(setup[1]))


def segundo(lista, ele):
    lista.remove(ele)
    return lista.index(ele)+1
# Clases y sus métodos


class Boton:
    def __init__(self, texto, forma, superficie, anchoLinea, color, color2, colorTexto, fuente, directorio=None,
                 scaleImagen=None, posImagen=None):
        self.forma = forma
        self.color = color
        self.color2 = color2
        self.superficie = superficie
        self.texto = texto
        self.fuente = fuente
        self.anchoLinea = anchoLinea
        self.directorio = directorio
        self.scaleImagen = scaleImagen
        self.posImagen = posImagen
        self.colorTexto = colorTexto

    def pintar(self):
        if self.forma.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(self.superficie, self.color,
                             self.forma, self.anchoLinea)
            texto = self.fuente.render(self.texto, True, self.colorTexto)
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))
        else:
            pygame.draw.rect(self.superficie, self.color2,
                             self.forma, self.anchoLinea)
            texto = self.fuente.render(self.texto, True, self.colorTexto)
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))

#         if imagenBT != '':
#             imagen = pygame.transform.scale(imagenBT, self.scaleImagen)
#             pantalla.blit(imagen, self.posImagen)

    def getForma(self):
        return self.forma


class Banco:
    def __init__(self, monto=int(setup[0]), monto_inicio=int(setup[2]), gran_acumulado=0):
        self.monto = monto
        self.dado1 = 0
        self.dado2 = 0
        self.gran_acumulado = gran_acumulado
        self.monto_inicio = monto_inicio

    global orden, ordenDado, actual, ordenDado1

    def tirarDado(self):
        self.dado1 = random.randrange(1, 7)
        self.dado2 = random.randrange(1, 7)

    def getDados(self):
        return self.dado1, self.dado2

    def deposita_granAcumulado(self, destinatario):
        destinatario.monto += self.gran_acumulado
        self.gran_acumulado = 0

    def ingresaGranAcumulado(self, jugador, monto):
        monto = abs(monto)
        jugador.monto -= monto
        self.gran_acumulado += monto

    def cobroBanco(self, jugador, destinatario, cantidad):
        jugador.monto -= cantidad
        destinatario.monto += cantidad

    def getMonto(self):
        return self.monto

    def ganador(self):

        montos = []
        cant = 0
        for propiedad in jugador1.propiedades:
            cant += propiedad.getValor()
        if type(jugador1.monto) == int or type(jugador1.monto) == float:
            cant += jugador1.monto
        montos.append(cant)
        cant = 0

        for propiedad in jugador2.propiedades:
            cant += propiedad.getValor()
        if type(jugador2.monto) == int or type(jugador2.monto) == float:
            cant += jugador2.monto
        montos.append(cant)
        cant = 0

        for propiedad in jugador3.propiedades:
            cant += propiedad.getValor()
        if type(jugador3.monto) == int or type(jugador3.monto) == float:
            cant += jugador3.monto
        montos.append(cant)
        cant = 0

        for propiedad in jugador4.propiedades:
            cant += propiedad.getValor()
        if type(jugador4.monto) == int or type(jugador4.monto) == float:
            cant += jugador4.monto
        montos.append(cant)
        cant = 0
        montos = dict(zip([jugador1, jugador2, jugador3, jugador4], montos))
        maximo = max(montos.values())
        ganadores = []
        for key, value in montos.items():
            if value == maximo:
                ganadores.append(key.getNick())

        return ganadores


class Jugador:
    def __init__(self, nickName, turno, monto, pos, estado, propiedades=[], image=None):
        self.nickName = nickName
        self.turno = turno
        self.monto = monto
        self.pos = pos
        self.propiedades = propiedades
        self.propiedadesNombres = ''
        self.estado = estado
        self.image = image
        self.penalizado = 3

    def compra(self, instanciaPropiedad):
        self.propiedades.append(instanciaPropiedad)

    def getmonto(self):
        return self.monto

    def actProp(self):
        for prop in self.propiedades:
            if prop.nombre+'\n' not in self.propiedadesNombres:
                self.propiedadesNombres += prop.nombre+'\n'

    def cobrar(self, monto):
        self.monto += monto

    def setEstado(self):
        self.estado = True

    def getNick(self):
        return self.nickName

    def update(self, pos, screen, dinero, prop, penal, casilla=None, propName=None):
        screen.blit(self.image, pos)
        self.monto = dinero
        self.propiedades = prop
        self.penalizado = penal

        if casilla is not None:
            self.pos = casilla
            self.propiedadesNombres = propName


class Propiedad:
    def __init__(self, nombre, pos, valor, derechoPaso, comprada=False, dueño=None):
        self.nombre = nombre
        self.pos = int(pos)
        self.valor = int(valor)
        self.derechoPasoo = derechoPaso
        self.comprada = comprada
        self.dueño = dueño

    def cambiaEstado(self, nuevo_dueño):
        self.comprada = True
        self.dueño = nuevo_dueño

    def getValor(self):
        return self.valor

    def getDerechoPaso(self):
        return self.derechoPasoo


def render_texto(text, x, y, fsize, screen, color=(0, 0, 0)):
    lines = text.splitlines()
    for i, l in enumerate(lines):
        font = pygame.font.SysFont('Arial', fsize)
        screen.blit(font.render(l, 0, color), (x, y + fsize*i))


casilla = pygame.Rect(200, 200, 200, 200)

banco = Banco()

inicial_x_jugador = int(setup[1])

# Jugadores
jugador1 = Jugador('Jose',  True,    inicial_x_jugador,
                   0, True, [], image=image_per)

jugador2 = Jugador('Gerald', False, inicial_x_jugador,
                   0, True, [], image=image_per2)

jugador3 = Jugador('Pedro', False, inicial_x_jugador,
                   0, False, [], image=image_per3)

jugador4 = Jugador('Juan', False, inicial_x_jugador,
                   0, False, [], image=image_per)

dueño_propiedad = None

# -------------------------------------------BOTONES------------------------------------------
btnIniciar = Boton('Iniciar', pygame.Rect(50, 50, 100, 70), screen,
                   0, (200, 200, 200), (120, 120, 120), (255, 255, 255), fuente)
btnTirarDados = Boton('Lanzar Dados', pygame.Rect(540, 310, 100, 100),
                      screen, 0, (200, 200, 200), (120, 120, 120), (255, 255, 255), fuente)
btnDos = Boton('2 Jugadores', pygame.Rect(300, 280, 130, 70),
               screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)
btnTres = Boton('3 Jugadores', pygame.Rect(550, 280, 130, 70),
                screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)
btnCuatro = Boton('4 Jugadores', pygame.Rect(800, 280, 130, 70),
                  screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)
btnTerminarPartida = Boton('Terminar Partida', pygame.Rect(1000, 50, 150, 70),
                           screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)


btnPagar_derecho_paso = Boton('Pagar derecho de paso', pygame.Rect(510, 380, 180, 50),
                              screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente)
btnComprar_propiedad = Boton('Comprar', pygame.Rect(480, 380, 100, 50),
                             screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente)
btnRechazar_compra = Boton('Rechazar', pygame.Rect(620, 380, 100, 50),
                           screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente)
btnAceptar = Boton('Aceptar', pygame.Rect(200, 380, 130, 70),
                   screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)
btnCarcelTirar = Boton('Lanzar Dados', pygame.Rect(430, 280, 150, 50),
                       screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)
btnPagarMulta = Boton('Pagar Multa', pygame.Rect(670, 280, 150, 50),
                      screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)
btnAceptarMulta = Boton('Pagar Multa', pygame.Rect(670, 120, 150, 50),
                        screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)
btnAceptarSalirGratis = Boton('Salir Gratis', pygame.Rect(570, 70, 150, 50),
                              screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)
btnAceptarFinalizado = Boton('Aceptar', pygame.Rect(470, 180, 150, 50),
                             screen, 0, (0, 61, 162), (0, 80, 213), (255, 255, 255), fuente2)


# Botones para los temas
btnTema = Boton('Temas', pygame.Rect(250, 50, 100, 50), screen,
                0, (200, 200, 200), (120, 120, 120), (255, 255, 255), fuente)

btnPlayas = Boton('Playas', pygame.Rect(100, 150, 100, 50), screen,
                  0, (200, 200, 200), (120, 120, 120), (255, 255, 255), fuente)
btnParques = Boton('Parques', pygame.Rect(250, 150, 100, 50), screen,
                   0, (200, 200, 200), (120, 120, 120), (255, 255, 255), fuente)
btnGAM = Boton('GAM', pygame.Rect(400, 150, 100, 50), screen,
               0, (200, 200, 200), (120, 120, 120), (255, 255, 255), fuente)
elegir_tema = False
se_eligio_tema = False


posiciones_casillas = {}


orden = [1, 2, 3, 4]
instancias = [jugador1, jugador2, jugador3, jugador4]
ordenNombres = dict(zip(orden, instancias))

nuevo_orden = {}
elegir_orden = True


ventana_propiedad = pygame.Surface((400, 200))
activa_ventana_propiedad = False


ventana_orden_partida = pygame.Surface((500, 500))
empezar_partida = False


# ---------------------Código de la carta de suerte-------------------

carta = pygame.image.load('carta.png')
carta = pygame.transform.scale(carta, (400, 400))


cartas_suerte = []
with open('suerte.txt', 'r', encoding='utf-8') as b:
    baraja = b.readlines()
    for line in baraja[2:]:
        line = strToList(line, len(line))
        cartas_suerte += [line]


tiempo_mostrando_carta = 0
se_tiro_dado = False
salirCarcel = False

# ------------------------------Bucle del juego------------------------------------
while running:
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = pygame.mouse.get_pos()  # Capturar posicion del mouse

            if btnPagarMulta.getForma().collidepoint(pos) and ordenNombres[actual].penalizado == 2:
                banco.ingresaGranAcumulado(ordenNombres[actual], int(setup[3]))
                ordenNombres[actual].penalizado = 3

            if btnCarcelTirar.getForma().collidepoint(pos) and ordenNombres[actual].penalizado == 2:
                ordenNombres[actual].penalizado = 3
                banco.tirarDado()
                salirCarcel = True
                if banco.getDados()[0] != banco.getDados()[1]:
                    pagarMulta = True
                else:
                    salirGratis = True

            if btnTerminarPartida.getForma().collidepoint(pos) and juegoActivo:
                banco.ganador()
                finalizado = True
                juegoActivo = False

            if btnAceptarFinalizado.getForma().collidepoint(pos) and finalizado:
                finalizado = False
                ganadoresListos = True

            if btnAceptarMulta.getForma().collidepoint(pos) and pagarMulta:
                banco.ingresaGranAcumulado(ordenNombres[actual], int(setup[3]))
                ordenNombres[actual].penalizado = 3
                pagarMulta = False
                salirCarcel = False

            if btnAceptarSalirGratis.getForma().collidepoint(pos) and salirGratis:
                ordenNombres[actual].penalizado = 3
                salirGratis = False
                salirCarcel = False

            # Eventos para eligir los temas del juego
            if btnTema.getForma().collidepoint(pos):
                elegir_tema = True

            if btnPlayas.getForma().collidepoint(pos) and elegir_tema:
                carpeta = 'Playas'
                fondo = pygame.image.load(f'{carpeta}/Fondo.jpeg')
                fondo = pygame.transform.scale(fondo, (1280, 720))
                elegir_tema = False
                se_eligio_tema = True

            if btnParques.getForma().collidepoint(pos) and elegir_tema:
                carpeta = 'Parques'
                fondo = pygame.image.load(f'{carpeta}/Fondo.jpeg')
                fondo = pygame.transform.scale(fondo, (1280, 720))
                elegir_tema = False
                se_eligio_tema = True

            if btnGAM.getForma().collidepoint(pos) and elegir_tema:
                carpeta = 'GAM'
                fondo = pygame.image.load(f'{carpeta}/Fondo.jpeg')
                fondo = pygame.transform.scale(fondo, (1280, 720))
                elegir_tema = False
                se_eligio_tema = True

            if btnIniciar.getForma().collidepoint(pos) and not juegoActivo and se_eligio_tema:
                finalizado = False
                cantJugadores = True
                establecerOrden = True
                empezar_partida = False
                jugadores_valor_max = []

                # Archivo de las propiedades
                with open(f'{carpeta}/prop.txt', 'r', encoding='utf-8') as P:
                    propiedades = P.readlines()
                caract_prop = []
                for line in propiedades:
                    caract_prop += [strToList(line, len(line))]

                # Propiedades
                verificar_propiedad = {}
                caract_prop = caract_prop[1:]
                ind_1 = 0
                for line in caract_prop:
                    propiedad = Propiedad(
                        caract_prop[ind_1][1], caract_prop[ind_1][0], caract_prop[ind_1][2], caract_prop[ind_1][3])
                    verificar_propiedad[propiedad.pos] = propiedad
                    ind_1 += 1
                    propiedadesInstancias.append(propiedad)

                # Lista las imagenes de la carpeta
                imagenes_casillas = {}
                imagenes = os.listdir(path=f'{carpeta}/Imagenes')
                for image in imagenes:
                    numero_casilla = image[:-5]  # Cap
                    numero_casilla = numero_casilla[-2:]
                    image = pygame.image.load(f'{carpeta}/Imagenes/{image}')
                    image = pygame.transform.scale(image, (100, 100))
                    imagenes_casillas[int(numero_casilla)] = image

            if (
                btnTirarDados.getForma().collidepoint(pos) and juegoActivo and not activa_ventana_propiedad and
                tiempo_mostrando_carta == 0 and not (
                    empezar_partida and elegir_orden) and not salirCarcel
            ):
                se_tiro_dado = True

                if not ordenNombres[actual].estado:
                    if actual < jugadoresActivos:
                        actual += 1
                    else:
                        actual = 1

                if ordenNombres[actual].penalizado == 3 and ordenNombres[actual].estado:
                    banco.tirarDado()

                    if not elegir_orden:

                        # Aumenta la casilla en la que se encuentra el jugador actual
                        for x in range(banco.getDados()[0]+banco.getDados()[1]):

                            if ordenNombres[actual].pos + 1 > 23:
                                ordenNombres[actual].pos = 0
                                banco.cobroBanco(
                                    banco, ordenNombres[actual], int(setup[2]))
                            else:
                                ordenNombres[actual].pos += 1

                        # Evento para pagar el derecho por paso
                        if (ordenNombres[actual].pos in verificar_propiedad and verificar_propiedad[ordenNombres[actual].pos].comprada == True
                                and ordenNombres[actual] != verificar_propiedad[ordenNombres[actual].pos].dueño):
                            dueño_propiedad = verificar_propiedad[ordenNombres[actual].pos].dueño
                            derecho_paso = verificar_propiedad[ordenNombres[actual].pos].getDerechoPaso(
                            )
                            jugador_a_pagar = ordenNombres[actual]
                            accion_mostrar = 'Cobrar'
                            activa_ventana_propiedad = True
                            nombre_propiedad = verificar_propiedad[ordenNombres[actual].pos]

                        # Evento para comprar una propiedad sin dueño
                        elif (ordenNombres[actual].pos in verificar_propiedad and verificar_propiedad[ordenNombres[actual].pos].comprada == False
                              and ordenNombres[actual].getmonto() >= verificar_propiedad[ordenNombres[actual].pos].valor):
                            accion_mostrar = 'Comprar?'
                            propiedad_comprar = verificar_propiedad[ordenNombres[actual].pos]
                            nombre_propiedad = verificar_propiedad[ordenNombres[actual].pos]
                            precio_propiedad = verificar_propiedad[ordenNombres[actual].pos].valor
                            posible_comprador = ordenNombres[actual]
                            activa_ventana_propiedad = True

                        # Evento para la cárcel
                        elif ordenNombres[actual].pos == 6:
                            ordenNombres[actual].penalizado = 0

                        # Evento para la casilla de parada libre
                        elif ordenNombres[actual].pos == 12:
                            banco.deposita_granAcumulado(ordenNombres[actual])

                        # Evento para la casilla de suerte
                        elif ordenNombres[actual].pos == 18:
                            sorpresa = random.choice(cartas_suerte)
                            tiempo_mostrando_carta = 5*60

                            if sorpresa[1] == '0':
                                if int(sorpresa[2]) < 0:
                                    banco.ingresaGranAcumulado(
                                        ordenNombres[actual], int(sorpresa[2]))
                                    text_carta = sorpresa[0]

                                else:
                                    banco.cobroBanco(
                                        banco, ordenNombres[actual], int(sorpresa[2]))
                                    text_carta = sorpresa[0]

                            if sorpresa[1] == '1':
                                if sorpresa[2] == '6':
                                    ordenNombres[actual].penalizado = 0

                                elif sorpresa[2] == '12':
                                    banco.deposita_granAcumulado(
                                        ordenNombres[actual])

                                ordenNombres[actual].pos = int(sorpresa[2])
                                text_carta = sorpresa[0]

                        if actual < jugadoresActivos:
                            actual += 1
                        else:
                            actual = 1

                    # Evento para saber quien empieza
                    elif elegir_orden:
                        nuevo_orden[ordenNombres[actual]] = banco.getDados()[0]
                        for ele in list(nuevo_orden.values()):
                            if list(nuevo_orden.values()).count(ele) > 1:
                                actual = segundo(
                                    list(nuevo_orden.values()), ele)

                        if actual < jugadoresActivos:
                            actual += 1
                        else:
                            nuevo_orden = dict(
                                sorted(nuevo_orden.items(), key=lambda x: x[1], reverse=True))

                            max_valor_dado = max(nuevo_orden.values())

                            jugadores_valor_max = [
                                key for key, value in nuevo_orden.items() if value == max_valor_dado]
                            # demas_jugadores = [
                            #   key for key in nuevo_orden.keys() if key != jugadores_valor_max[0]]

                            if len(jugadores_valor_max) == 1:

                                instancias = [key for key,
                                              value in nuevo_orden.items()]

                                ordenNombres = dict(zip(orden, instancias))

                                empezar_partida = True

                            actual = 1

                    tirar = True

                elif ordenNombres[actual].penalizado == 0:
                    ordenNombres[actual].penalizado = 1
                    if actual < jugadoresActivos:
                        actual += 1
                    else:
                        actual = 1

            if btnDos.getForma().collidepoint(pos) and cantJugadores:
                juegoActivo = True
                cantJugadores = False
                jugadoresActivos = 2

            if btnTres.getForma().collidepoint(pos) and cantJugadores:
                juegoActivo = True
                jugador3.setEstado()
                cantJugadores = False
                jugadoresActivos = 3

            if btnCuatro.getForma().collidepoint(pos) and cantJugadores:
                juegoActivo = True
                jugador4.setEstado()
                jugador3.setEstado()
                cantJugadores = False
                jugadoresActivos = 4

            if btnPagar_derecho_paso.getForma().collidepoint(pos) and activa_ventana_propiedad and accion_mostrar == 'Cobrar':
                banco.cobroBanco(
                    jugador_a_pagar, dueño_propiedad, int(derecho_paso))
                activa_ventana_propiedad = False

            if btnComprar_propiedad.getForma().collidepoint(pos) and activa_ventana_propiedad and accion_mostrar == 'Comprar?':
                propiedad_comprar.cambiaEstado(posible_comprador)
                posible_comprador.compra(nombre_propiedad)
                banco.cobroBanco(posible_comprador, banco,
                                 int(precio_propiedad))
                activa_ventana_propiedad = False

            if btnRechazar_compra.getForma().collidepoint(pos) and activa_ventana_propiedad and accion_mostrar == 'Comprar?':
                activa_ventana_propiedad = False

            if btnAceptar.getForma().collidepoint(pos) and empezar_partida:
                elegir_orden = False

# ---------------------------Renderización del juego-------------------------------
    screen.fill((255, 255, 255))
    if se_eligio_tema:
        screen.blit(fondo, (0, 0))

    if not juegoActivo:
        btnTema.pintar()
        if elegir_tema:
            btnParques.pintar()
            btnPlayas.pintar()
            btnGAM.pintar()
        if se_eligio_tema:
            btnIniciar.pintar()

    if juegoActivo:

        # Coloca las casillas
        casillas_x, casillas_y = 850, 600
        for num_casilla, image in imagenes_casillas.items():

            if num_casilla <= 6:

                pos_casilla = (casillas_x - 100*num_casilla, casillas_y)
                screen.blit(image, pos_casilla)

            if 6 < num_casilla <= 12:

                pos_casilla = (casillas_x - 100 * 6,
                               casillas_y - 100 * (num_casilla-6))
                screen.blit(image, pos_casilla)

            if 12 < num_casilla <= 18:

                pos_casilla = ((casillas_x - 100 * 6) + 100 * (num_casilla-12),
                               (casillas_y - 100 * 6))
                screen.blit(image, pos_casilla)

            if 18 < num_casilla:

                pos_casilla = ((casillas_x - 0),
                               (casillas_y - 100 * 6) + 100 * (num_casilla-18))
                screen.blit(image, pos_casilla)

            # Ordena las posiciones de las casillas
            posiciones_casillas[num_casilla] = (pos_casilla)

        for prop in propiedadesInstancias:
            propSurface = pygame.Surface((100, 20))
            propSurface.fill((0, 0, 0))
            textoPropiedad = fuente3.render(prop.nombre, True, (255, 255, 255))
            propSurface.blit(textoPropiedad, (0, 0))
            screen.blit(propSurface, posiciones_casillas[prop.pos])

            btnTerminarPartida.pintar()

        if se_tiro_dado == False:
            btnTirarDados.pintar()

        textoTurno = fuente2.render(
            f'Es turno de {ordenNombres[actual].getNick()}', True, (0, 0, 0))
        screen.blit(textoTurno, (520, 450))

        # Dibuja cada dado dependido de su valor
        if banco.getDados()[0] == 1:
            screen.blit(uno, (540, 310))
        if banco.getDados()[0] == 2:
            screen.blit(dos, (540, 310))
        if banco.getDados()[0] == 3:
            screen.blit(tres, (540, 310))
        if banco.getDados()[0] == 4:
            screen.blit(cuatro, (540, 310))
        if banco.getDados()[0] == 5:
            screen.blit(cinco, (540, 310))
        if banco.getDados()[0] == 6:
            screen.blit(seis, (540, 310))

        if not elegir_orden:
            if banco.getDados()[1] == 1:
                screen.blit(uno, (540, 220))
            if banco.getDados()[1] == 2:
                screen.blit(dos, (540, 220))
            if banco.getDados()[1] == 3:
                screen.blit(tres, (540, 220))
            if banco.getDados()[1] == 4:
                screen.blit(cuatro, (540, 220))
            if banco.getDados()[1] == 5:
                screen.blit(cinco, (540, 220))
            if banco.getDados()[1] == 6:
                screen.blit(seis, (540, 220))
        # Actualiza las posiciones de los jugadores
        jugador1.update(posiciones_casillas[jugador1.pos], screen,
                        jugador1.monto, jugador1.propiedades, jugador1.penalizado)
        nombreJugador1 = fuente3.render(
            str(jugador1.getNick()), True, (0, 0, 0))
        screen.blit(nombreJugador1, posiciones_casillas[jugador1.pos])
        info_jugador1 = f'Jugador: {jugador1.nickName}\nMonto disponible: {jugador1.getmonto()} \nPropiedades:\n{jugador1.propiedadesNombres}'
        render_texto(info_jugador1, 10, 150, 15, screen)

        jugador2.update(posiciones_casillas[jugador2.pos], screen,
                        jugador2.monto, jugador2.propiedades, jugador2.penalizado)
        info_jugador2 = f'Jugador: {jugador2.nickName}\nMonto disponible: {jugador2.getmonto()} \nPropiedades:\n{jugador2.propiedadesNombres}'
        nombreJugador2 = fuente3.render(
            str(jugador2.getNick()), True, (255, 255, 255))
        screen.blit(nombreJugador2, posiciones_casillas[jugador2.pos])

        render_texto(info_jugador2, 1050, 150, 15, screen)
        if jugadoresActivos == 2:
            jugador3.monto = 0
            jugador4.monto = 0

        if jugadoresActivos == 3:
            jugador4.monto = 0

        if jugadoresActivos == 3 or jugadoresActivos == 4:
            jugador3.update(posiciones_casillas[jugador3.pos], screen,
                            jugador3.monto, jugador3.propiedades, jugador3.penalizado)
            info_jugador3 = f'Jugador: {jugador3.nickName}\nMonto disponible: {jugador3.getmonto()} \nPropiedades:\n{jugador3.propiedadesNombres}'
            render_texto(info_jugador3, 10, 550, 15, screen)
            nombreJugador3 = fuente3.render(
                str(jugador3.getNick()), True, (255, 255, 255))
            screen.blit(nombreJugador3, posiciones_casillas[jugador3.pos])

        if jugadoresActivos == 4:
            jugador4.update(posiciones_casillas[jugador4.pos], screen,
                            jugador4.monto, jugador4.propiedades, jugador4.penalizado)
            info_jugador4 = f'Jugador: {jugador4.nickName}\nMonto disponible: {jugador4.getmonto()} \nPropiedades:\n{jugador4.propiedadesNombres}'
            render_texto(info_jugador4, 1050, 550, 15, screen)
            nombreJugador4 = fuente3.render(
                str(jugador4.getNick()), True, (0, 0, 0))
            screen.blit(nombreJugador4, posiciones_casillas[jugador4.pos])

        text_gran_acumulado = f'Gran Acumulado:\n{banco.gran_acumulado}'
        render_texto(text_gran_acumulado, 400, 150, 30, screen)

        if elegir_orden:
            ventana_orden_partida.fill((200, 200, 200))
            x_or, y_or = 100, 200
            for jugador, dado in nuevo_orden.items():
                text_orden = f'Jugador: {jugador.getNick()}, Dado: {dado}'
                render_texto(text_orden, x_or, y_or,
                             15, ventana_orden_partida)
                # x_or += 100
                y_or += 50

            screen.blit(ventana_orden_partida, (0, 0))

            if empezar_partida == True:
                btnAceptar.pintar()

# ----------------------------Casillas----------------------------------
    if 0 < tiempo_mostrando_carta <= 5*60:
        screen.blit(carta, (400, 160))
        render_texto(text_carta, 430, 280, 20, screen, (255, 255, 255))
        tiempo_mostrando_carta -= 2

    # Ventana para cobrar el derecho de paso
    if activa_ventana_propiedad:
        ventana_propiedad.fill((0, 0, 0))

        if accion_mostrar == 'Cobrar':
            mensaje_mostrar = f'Propiedad de: {dueño_propiedad.nickName}\nDebe pagar: {derecho_paso}'

        elif accion_mostrar == 'Comprar?':
            mensaje_mostrar = f'Deseea comprar la propiedad: {nombre_propiedad.nombre}\nCon costo de: {precio_propiedad}'

        render_texto(mensaje_mostrar, 50, 50, 15,
                     ventana_propiedad, (255, 255, 255))

        screen.blit(ventana_propiedad, (400, 250))

        if accion_mostrar == 'Cobrar':
            btnPagar_derecho_paso.pintar()

        elif accion_mostrar == 'Comprar?':
            btnComprar_propiedad.pintar()
            btnRechazar_compra.pintar()

    if ordenNombres[actual].penalizado == 1:
        ordenNombres[actual].penalizado = 2
    if ordenNombres[actual].penalizado == 2:
        ventanaSalirCarcel = pygame.Surface((500, 200))
        ventanaSalirCarcel.fill((0, 0, 0))
        screen.blit(ventanaSalirCarcel, (350, 200))
        btnPagarMulta.pintar()
        btnCarcelTirar.pintar()

    if cantJugadores:
        textoCant = fuente2.render(
            'Seleccione la cantidad de jugadores', True, (255, 255, 255))
        pantallaCant.fill((0, 0, 0))
        pantallaCant.blit(textoCant, (175, 50))
        screen.blit(pantallaCant, (270, 75))
        btnDos.pintar()
        btnTres.pintar()
        btnCuatro.pintar()

    # Evento para salir de la carcel despues de tirar los dados
    if salirCarcel:
        salirCarcelSuperficie.fill((0, 0, 0))
        if pagarMulta:
            textoPagarMulta = fuente2.render(
                'Debe pagar la multa', True, (255, 255, 255))
            salirCarcelSuperficie.blit(textoPagarMulta, (50, 50))
            screen.blit(salirCarcelSuperficie, (270, 75))
            btnAceptarMulta.pintar()

        # Salen dobles
        else:
            salirCarcelSuperficie.fill((0, 0, 0))
            textoSaleGratis = fuente2.render(
                '¡No debe pagar multa!', True, (255, 255, 255))
            salirCarcelSuperficie.blit(textoSaleGratis, (50, 50))
            screen.blit(salirCarcelSuperficie, (50, 50))
            btnAceptarSalirGratis.pintar()

    # Evento para terminar partida
    # if finalizado:
    if ganadoresListos:

        banco = Banco()

        jugador1.update(
            posiciones_casillas[0], screen, inicial_x_jugador, [], 3, 0, '')
        jugador2.update(
            posiciones_casillas[0], screen, inicial_x_jugador, [], 3, 0, '')
        jugador3.update(
            posiciones_casillas[0], screen, inicial_x_jugador, [], 3, 0, '')
        jugador4.update(
            posiciones_casillas[0], screen, inicial_x_jugador, [], 3, 0, '')

        elegir_orden = True
        nuevo_orden = {}
        orden = [1, 2, 3, 4]
        instancias = [jugador1, jugador2, jugador3, jugador4]
        ordenNombres = dict(zip(orden, instancias))
        se_tiro_dado = False
        actual = 1
        ganadoresListos = False

    if finalizado:
        finalizadoSurface.fill((0, 0, 0))
        texto2Finalizado = fuente2.render('Ganador/es', True, (255, 255, 255))
        textoFinalizado = fuente2.render(
            str(banco.ganador())[1:-1], True, (255, 255, 255))
        finalizadoSurface.blit(textoFinalizado, (50, 50))
        finalizadoSurface.blit(texto2Finalizado, (50, 20))
        screen.blit(finalizadoSurface, (50, 50))
        btnAceptarFinalizado.pintar()

    for num in ordenNombres:
        if (type(ordenNombres[num].monto) == float or type(ordenNombres[num].monto) == int) and ordenNombres[num].monto < 0 and juegoActivo:
            ordenNombres[num].estado = False
            ordenNombres[num].monto = '¡Banca Rota!'

    # Coloca los nombres de las propiedades
    jugador1.actProp()
    jugador2.actProp()
    jugador3.actProp()
    jugador4.actProp()
    pygame.display.flip()
    clock.tick(60)
pygame.quit()
