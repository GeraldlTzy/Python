# Bibliotecas
import pygame
import sys
import os
import random
import time

# Setup
pygame.init()
pantalla = pygame.display.set_mode((1280, 720), pygame.RESIZABLE)
running = True
clock = pygame.time.Clock()
fuente = pygame.font.SysFont('Liberation  Serif', 20)  # Fuente del texto
gameOverFont = pygame.font.SysFont('Liberation  Serif', 50)
fondo = pygame.image.load('imagenes/Logo.png').convert()
fondo = pygame.transform.scale(fondo, (1280, 720))

# Se inicializan las variables para el laberinto
laberinto_level_1 = []
espaciado_x = 100
espaciado_y = 100

# Texturas del laberinto báscico
suelo_tex = pygame.image.load('imagenes/textTierra.jpg')
suelo_tex = pygame.transform.scale(suelo_tex, (espaciado_x, espaciado_y))

pared = pygame.image.load('imagenes/pared.jpg')
pared = pygame.transform.scale(pared, (espaciado_x, espaciado_y))

banderaSalida = pygame.image.load('imagenes/bandera.png')
banderaSalida = pygame.transform.scale(
    banderaSalida, (espaciado_x, espaciado_y))

flecha = pygame.image.load('imagenes/flechaSolucion.jpeg')
flecha = pygame.transform.scale(flecha, (espaciado_x, espaciado_y))

# Personaje
x_personaje, y_personaje = 0, 0
x_personaje2, y_personaje2 = 0, 0

personaje_no_movido = True

imagenPersonaje = 'imagenes/personaje.png'
imagenPersonaje2 = 'imagenes/personaje2.png'
x = 20
y = 20

# Inicialización de los laberinto
cantidad_fila = len(laberinto_level_1)
colocar_laberinto = False
fila_laberinto = 0
modo_juego = ''
cambio_nivel = False
colision = False
nivel_laberinto = 0
jugando = False

# Laberinto cuadros
suelo = []
pared_ = []
posicion_suelo = []
movimiento_monstruos = []
salidas_laberinto = []
recorridos = []
# Tamaño del laberinto
alto_mundo = 0
ancho_mundo = 0

# Tiempo para salir del laberinto
tiempoRestante = 5 * 60
text_t = fuente.render(str(tiempoRestante), True, (0, 0, 0))
tiempo = 0

# Camara
camara_x = 0
camara_y = 0

camara_x2 = 0
camara_y2 = 360


direccion_y = 'arriba'
direccion_x = 'derecha'

# Efectos sobre el jugador 1
efecto_congelacion_player1 = False
tiempo_congelacion_player1 = 5 * 60
muerte_player1 = False
descongelando_player1 = False

# Efectos sobre el jugador 2
efecto_congelacion_player2 = False
tiempo_congelacion_player2 = 5 * 60
muerte_player2 = False
descongelando_player2 = False

# Pantallas para el modo competitivo
pantalla1 = pantalla.subsurface(pygame.Rect(0, 0, 1280, 360))
pantalla2 = pantalla.subsurface(pygame.Rect(0, 360, 1280, 360))

# Para el puntaje
with open('puntajeLaberinto.txt', 'r') as P:
    contenidoPuntaje = P.read()
    textos = list(contenidoPuntaje)
puntaje = 0
puntaje2 = 0
min = 0
max = 8
competitivoPuntos = False
# Los caracteres permitidos
caract = 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ñ', 'z', 'x', 'c', 'v', 'b', 'n', 'm'
numeros = '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'
puntaje_activado = False
texto_input = ''
competidores = []
puntosCompetidores = []
esp = 0

# Solución de laberintos
resolver = False
mostrar = False
cuadrosSolucion = []
camino = []

# Para la imagen del boton
imagenBT = ''
# ---------------------------------------------------------Para-la-solucion-----------------------------------------------------------------------------------------------------------------------------------
solucion = 0  # Esta variable alterna entre 0,1,2,3,4 y representa el movimiento del personaje para recorrer la solucion
# 0 es estatico, 1 es derecha, 2 es izquierda, 3 es arriba y 4 abajo.
# contrario=0 #Esta variable permite establecer el estado contrario de 'solucion' para no revertir el proceso innecesariamente

# Cursor de solucion
cursor = pygame.image.load('imagenes/solucion.jpeg')
cursor = pygame.transform.scale(cursor, ((espaciado_x), (espaciado_y)))
x_cursor, y_cursor = 0, 0

estadoSolucion = False

prohibidos = []
HaySolucion = True  # Para activar la ventana con el mensaje
cuenta = 0
direccion = []
avanza = 0

# Cuando termina la partida
cuadroMuerte = False
cuadroMuerte2 = False
avent = False
simple = False
compet = False
per1 = False
per2 = False

timeOver = False
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------Clases y sus Metodos-----------------------------------------------------


class Boton:
    def __init__(self, texto, forma, superficie, anchoLinea, directorio=None,
                 scaleImagen=None, posImagen=None, color=None, color2=None):
        self.forma = forma
        self.color = color
        self.color2 = color2
        self.superficie = superficie
        self.texto = texto
        self.anchoLinea = anchoLinea
        self.directorio = directorio
        self.scaleImagen = scaleImagen
        self.posImagen = posImagen

    def pintar(self):
        if self.forma.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(self.superficie, colorBotones1,
                             self.forma, self.anchoLinea)
            texto = fuente.render(self.texto, True, colorTexto)
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))
        else:
            pygame.draw.rect(self.superficie, colorBotones2,
                             self.forma, self.anchoLinea)
            texto = fuente.render(self.texto, True, colorTexto)
            self.superficie.blit(texto, (self.forma.x + (self.forma.width - texto.get_width()) / 2,
                                         self.forma.y + (self.forma.height - texto.get_height()) / 2))

        if imagenBT != '':
            imagen = pygame.transform.scale(imagenBT, self.scaleImagen)
            pantalla.blit(imagen, self.posImagen)

    def getForma(self):
        return self.forma

    # def set_imagen(self, )


class Enemy:
    def __init__(self, speed, screen, imagen, efecto):
        global espaciado_x, espaciado_y, posicion_suelo, movimiento_monstruos, modo_juego

        self.speed = speed
        self.image = pygame.image.load(imagen)
        self.image = pygame.transform.scale(
            self.image, (espaciado_x, espaciado_y))  # Escala la imagen a 50x50
        self.screen = screen
        self.posicion_establecida = False
        self.colision = False
        self.direcion = 'arriba'
        self.movimientos = ['arriba', 'abajo', 'izquierda', 'derecha']
        self.x = 0
        self.y = 900
        self.efecto = efecto
        self.reiniciar_posiciones = True

    def set_screen(self, screen):
        self.screen = screen

    def set_reinicio(self, reiniciar_posiciones):
        self.reiniciar_posiciones = reiniciar_posiciones

    def update(self):
        global x_personaje, y_personaje, efecto_congelacion_player1, espaciado_x, espaciado_y, reiniciar_posiciones, colocar_laberinto, modo_juego, pantalla
        global efecto_congelacion_player2, x_personaje2, y_personaje2, muerte_player1, muerte_player2, avent, per2, per1, compet, cuadroMuerte

        # Establecer una posicion aleatoria del enemigo en el laberinto
        if posicion_suelo and self.reiniciar_posiciones == True:
            self.x, self.y = random.choice(posicion_suelo)
            self.x *= 1
            self.y *= 1
            self.reiniciar_posiciones = False

        # Movimientos del personaje, se hacen aleatoriamente
        if self.direcion == 'abajo':
            self.colision = True
            for coordenas in movimiento_monstruos:
                if coordenas.collidepoint(self.x, self.y + self.speed[1]) or coordenas.collidepoint(
                        self.x + espaciado_x * .7, self.y + self.speed[1] + espaciado_y * .8):
                    self.colision = False
                    nuevo_movimiento = [
                        ele for ele in self.movimientos if ele != 'abajo']
                    self.direcion = random.choice(nuevo_movimiento)
                    break

            if self.colision == True and self.direcion == 'abajo':
                self.y += self.speed[1]

        if self.direcion == 'arriba':
            self.colision = True
            for coordenas in movimiento_monstruos:
                if coordenas.collidepoint(self.x, self.y - self.speed[1]) or coordenas.collidepoint(
                        self.x + espaciado_x * .7, self.y - self.speed[1]):
                    self.colision = False
                    nuevo_movimiento = [
                        ele for ele in self.movimientos if ele != 'arriba']
                    self.direcion = random.choice(nuevo_movimiento)
                    break

            if self.colision == True and self.direcion == 'arriba':
                self.y -= self.speed[1]

        if self.direcion == 'derecha':
            self.colision = True
            for coordenas in movimiento_monstruos:
                if coordenas.collidepoint(self.x + espaciado_x * .7 + self.speed[0], self.y) or coordenas.collidepoint(
                        self.x + espaciado_x * .7 + self.speed[0], self.y + espaciado_y * .7):
                    self.colision = False
                    nuevo_movimiento = [
                        ele for ele in self.movimientos if ele != 'derecha']
                    self.direcion = random.choice(nuevo_movimiento)
                    break

            if self.colision == True and self.direcion == 'derecha':
                self.x += self.speed[0]

        if self.direcion == 'izquierda':
            self.colision = True
            for coordenas in movimiento_monstruos:
                if coordenas.collidepoint(self.x - self.speed[0], self.y) or coordenas.collidepoint(
                        self.x - self.speed[0], self.y + espaciado_y * .7):
                    self.colision = False
                    nuevo_movimiento = [
                        ele for ele in self.movimientos if ele != 'izquierda']
                    self.direcion = random.choice(nuevo_movimiento)
                    break

            if self.colision == True and self.direcion == 'izquierda':
                self.x -= self.speed[0]

        # Efectos sobre primer jugador
        if self.screen == pantalla1 or self.screen == pantalla:
            if self.efecto == 'congelación':
                if (pygame.Rect(x_personaje, y_personaje, espaciado_x, espaciado_y).collidepoint(self.x, self.y)
                        or pygame.Rect(x_personaje, y_personaje, espaciado_x, espaciado_y).collidepoint(self.x,
                                                                                                        self.y + espaciado_y) or pygame.Rect(x_personaje, y_personaje, espaciado_x, espaciado_y).collidepoint(self.x + espaciado_x,
                                                                                                                                                                                                              self.y) or pygame.Rect(x_personaje, y_personaje, espaciado_x, espaciado_y).collidepoint(self.x + espaciado_y,
                                                                                                                                                                                                                                                                                                              self.y + espaciado_y)
                    ):
                    efecto_congelacion_player1 = True

            elif self.efecto == 'muerte':
                if (pygame.Rect(x_personaje, y_personaje, espaciado_x, espaciado_y).collidepoint(self.x, self.y)
                        or pygame.Rect(x_personaje, y_personaje, espaciado_x, espaciado_y).collidepoint(self.x,
                                                                                                        self.y + espaciado_y) or pygame.Rect(x_personaje, y_personaje, espaciado_x, espaciado_y).collidepoint(self.x + espaciado_x,
                                                                                                                                                                                                              self.y) or pygame.Rect(x_personaje, y_personaje, espaciado_x, espaciado_y).collidepoint(self.x + espaciado_y,
                                                                                                                                                                                                                                                                                                              self.y + espaciado_y)
                    ):

                    muerte_player1 = True
                    cuadroMuerte = True
                    if modo_juego == 'Competitivo':
                        compet = True
                        per1 = True
                    if modo_juego == 'Aventura':
                        avent = True
                        colocar_laberinto = False
                        modo_juego = 'finalizado'

        # Efectos sobre segundo jugador
        if modo_juego == 'Competitivo' and self.screen == pantalla2:
            if self.efecto == 'congelación':
                if (pygame.Rect(x_personaje2, y_personaje2, espaciado_x, espaciado_y).collidepoint(self.x, self.y)
                        or pygame.Rect(x_personaje2, y_personaje2, espaciado_x, espaciado_y).collidepoint(self.x,
                                                                                                          self.y + espaciado_y) or pygame.Rect(x_personaje2, y_personaje2, espaciado_x, espaciado_y).collidepoint(self.x + espaciado_x,
                                                                                                                                                                                                                  self.y) or pygame.Rect(x_personaje2, y_personaje2, espaciado_x, espaciado_y).collidepoint(self.x + espaciado_y,
                                                                                                                                                                                                                                                                                                                    self.y + espaciado_y and efecto_congelacion_player2 == False)
                    ):
                    efecto_congelacion_player2 = True

            elif self.efecto == 'muerte':
                if (pygame.Rect(x_personaje2, y_personaje2, espaciado_x, espaciado_y).collidepoint(self.x, self.y)
                        or pygame.Rect(x_personaje2, y_personaje2, espaciado_x, espaciado_y).collidepoint(self.x,
                                                                                                          self.y + espaciado_y) or pygame.Rect(x_personaje2, y_personaje2, espaciado_x, espaciado_y).collidepoint(self.x + espaciado_x,
                                                                                                                                                                                                                  self.y) or pygame.Rect(x_personaje2, y_personaje2, espaciado_x, espaciado_y).collidepoint(self.x + espaciado_y,
                                                                                                                                                                                                                                                                                                                    self.y + espaciado_y)
                    ):

                    muerte_player2 = True
                    compet = True
                    per2 = True
                    cuadroMuerte = True
        # Dibuja el enemigo en la pantalla

    def colocar(self, x_=0, y_=0):
        if self.posicion_establecida == True:
            self.screen.blit(self.image, (self.x - x_, self.y - y_))

        else:
            self.screen.blit(self.image, (self.x - x_, self.y - y_))

    def set_imagen(self, imagen):
        self.image = pygame.image.load(imagen)
        self.image = pygame.transform.scale(
            self.image, (espaciado_x, espaciado_y))
        if self.direcion == 'izquierda':
            self.image = pygame.transform.flip(self.image, True, False)


class Personaje:
    def __init__(self, jugador, ancho, alto, screen, imagen, x, y):
        self.ancho = ancho
        self.alto = alto
        self.screen = screen
        self.imagen = pygame.image.load(imagen)
        self.imagen = pygame.transform.scale(self.imagen, (ancho, alto))
        self.x = x
        self.y = y
        self.colision = False
        self.direccion = 'derecha'
        self.posicion_establecida = False
        self.jugador = jugador
        self.velocidad = 5

    def set_imagen(self, imagen):
        self.imagen = pygame.image.load(imagen)
        self.imagen = pygame.transform.scale(
            self.imagen, (self.ancho, self.alto))
        if self.direccion == 'izquierda':
            self.imagen = pygame.transform.flip(self.imagen, True, False)

    def update(self):
        global pared_, personaje_no_movido, y_personaje, x_personaje, ancho_mundo, camara_x, camara_y, camara_x2, camara_y2
        global x_personaje2, y_personaje2, efecto_congelacion_player1,  alto_mundo, descongelando_player1, descongelando_player2

        if self.jugador == 'jugador 1':
            if descongelando_player1 == True:
                self.velocidad = 2.5
            else:
                self.velocidad = 5

            self.x = x_personaje
            self.y = y_personaje

            if pygame.key.get_pressed()[pygame.K_w] and efecto_congelacion_player1 == False and y_personaje >= 0:
                for rect in pared_:
                    if rect.collidepoint((self.x, self.y - 5)) == True or rect.collidepoint(
                            (self.x + self.ancho * .90, self.y - 5)) == True:
                        self.colision = True
                        break
                    else:
                        self.colision = False
                if self.colision == False:
                    self.y -= self.velocidad
                    personaje_no_movido = False

            if pygame.key.get_pressed()[pygame.K_s] and efecto_congelacion_player1 == False and y_personaje <= alto_mundo-espaciado_y:
                for rect in pared_:
                    if rect.collidepoint((self.x, self.y + 5 + self.alto * .90)) == True or rect.collidepoint(
                            (self.x + self.ancho * .90, self.y + self.alto * .90 + 5)) == True:
                        self.colision = True
                        break
                    else:
                        self.colision = False
                if self.colision == False:
                    self.y += self.velocidad
                    personaje_no_movido = False

            if pygame.key.get_pressed()[pygame.K_a] and self.x > 0 and efecto_congelacion_player1 == False and x_personaje >= 0:
                for rect in pared_:
                    if rect.collidepoint((self.x - 5, self.y)) == True or rect.collidepoint(
                            (self.x - 5, self.y + self.alto * .90)) == True:
                        self.colision = True
                        break
                    else:
                        self.colision = False
                if self.colision == False:
                    self.x -= self.velocidad
                    personaje_no_movido = False
                    if self.direccion != 'izquierda':
                        self.imagen = pygame.transform.flip(
                            self.imagen, True, False)
                        self.direccion = 'izquierda'

            if pygame.key.get_pressed()[pygame.K_d] and self.x <= ancho_mundo - espaciado_x and efecto_congelacion_player1 == False:
                for rect in pared_:
                    if rect.collidepoint(
                            (self.x + self.ancho * .90 + 5, self.y)) == True or rect.collidepoint(
                            (self.x + self.ancho * .90 + 5, self.y + self.alto * .90)) == True:
                        self.colision = True
                        break
                    else:
                        self.colision = False
                if self.colision == False:
                    self.x += self.velocidad
                    personaje_no_movido = False
                    if self.direccion != 'derecha':
                        self.imagen = pygame.transform.flip(
                            self.imagen, True, False)
                        self.direccion = 'derecha'
            x_personaje = self.x
            y_personaje = self.y
            self.screen.blit(
                self.imagen, (self.x - camara_x, self.y - camara_y))

        elif self.jugador == 'jugador 2':
            if descongelando_player2 == True:
                self.velocidad = 2.5
            else:
                self.velocidad = 5

            self.x = x_personaje2
            self.y = y_personaje2

            if pygame.key.get_pressed()[pygame.K_UP] and efecto_congelacion_player2 == False and y_personaje2 >= 0:
                for rect in pared_:
                    if rect.collidepoint((self.x, self.y - 5)) == True or rect.collidepoint(
                            (self.x + self.ancho * .9, self.y - 5)) == True:
                        self.colision = True
                        break
                    else:
                        self.colision = False
                if self.colision == False:
                    self.y -= self.velocidad
                    personaje_no_movido = False

            if pygame.key.get_pressed()[pygame.K_DOWN] and efecto_congelacion_player2 == False and y_personaje2 <= alto_mundo - espaciado_y:
                for rect in pared_:
                    if rect.collidepoint((self.x, self.y + 5 + self.alto * .9)) == True or rect.collidepoint(
                            (self.x + self.ancho * .9, self.y + self.alto * .9 + 5)) == True:
                        self.colision = True
                        break
                    else:
                        self.colision = False
                if self.colision == False:
                    self.y += self.velocidad
                    personaje_no_movido = False

            if pygame.key.get_pressed()[pygame.K_LEFT] and self.x > 0 and efecto_congelacion_player2 == False and x_personaje2 >= 0:
                for rect in pared_:
                    if rect.collidepoint((self.x - 5, self.y)) == True or rect.collidepoint(
                            (self.x - 5, self.y + self.alto * .9)) == True:
                        self.colision = True
                        break
                    else:
                        self.colision = False
                if self.colision == False:
                    self.x -= self.velocidad
                    personaje_no_movido = False
                    if self.direccion != 'izquierda':
                        self.imagen = pygame.transform.flip(
                            self.imagen, True, False)
                        self.direccion = 'izquierda'

            if pygame.key.get_pressed()[pygame.K_RIGHT] and self.x <= ancho_mundo - espaciado_x and efecto_congelacion_player2 == False:
                for rect in pared_:
                    if rect.collidepoint(
                            (self.x + self.ancho * .9 + 5, self.y)) == True or rect.collidepoint(
                            (self.x + self.ancho * .9 + 5, self.y + self.alto * .9)) == True:
                        self.colision = True
                        break
                    else:
                        self.colision = False
                if self.colision == False:
                    self.x += self.velocidad
                    personaje_no_movido = False
                    if self.direccion != 'derecha':
                        self.imagen = pygame.transform.flip(
                            self.imagen, True, False)
                        self.direccion = 'derecha'

            x_personaje2 = self.x
            y_personaje2 = self.y
            self.screen.blit(
                self.imagen, (self.x - camara_x2, self.y - camara_y2))

# ---------------------------------------------FUNCION PARA GENERAR LABERINTOS------------------------------------------------------------
# columna_inicio = random.randrange(1, columnas - 1, 2)


def generar_laberinto(filas, columnas):

    # Se inicia la matriz del laberinto con paredes
    matriz = [[1 for j in range(columnas)] for i in range(filas)]

    # Se escoge una posición aleatoria como inicio y la salida
    fila_inicio = random.randrange(1, filas - 1, 2)
    columna_inicio = 1

    fila_inicio2 = random.randrange(1, filas - 1)  # Para el segundo jugador
    columna_inicio2 = 1

    salida = random.randint(1, filas - 1)  # Generar la salida

    # Se marca como 0 para que sea camino
    matriz[fila_inicio][columna_inicio] = 0
    laberinto = [(fila_inicio, columna_inicio)]

    while laberinto:
        # Se coloca la posicion de inicio
        fila_actual, columna_actual = laberinto[-1]

        # La idea de las casillas cercanas y no visitadas fue basada en el video de YouTube [1]:
        # [1] M. Guerrero ''Laberinto por BFS'', Octubre, 2020. [Online], disponible en: https://youtu.be/fR5jDZJ6u5w [Accedido Mayo. 15, 2023]

        # Las columnas que están o mejor dicho cuadrados que están al rededor del cuadrado actual, es decir, derecha, izquierda, arriba y abajo
        casillas_cercanas = [(fila_actual - 2, columna_actual), (fila_actual + 2, columna_actual),
                             (fila_actual, columna_actual - 2), (fila_actual, columna_actual + 2)]

        # Una lista con las ubicaciones que aún no se han visitado, porque son las que están alrededor
        casillas_no_visitadas = [(fila, columna) for fila, columna in casillas_cercanas
                                 if 0 <= fila < filas and 0 <= columna < columnas and matriz[fila][columna] == 1]

        if casillas_no_visitadas:
            siguiente_fila, siguiente_columna = random.choice(
                casillas_no_visitadas)  # Siguiente cuadro a ir

            # Se coloca un 0, para establecerlo como camino
            matriz[siguiente_fila][siguiente_columna] = 0

            # Se divide entre 2, para saber cual es el cuadro más cercano que lleva al siguiente
            matriz[(fila_actual + siguiente_fila) //
                   2][(columna_actual + siguiente_columna) // 2] = 0

            # Agrega la úbicacion para explorar
            laberinto += [(siguiente_fila, siguiente_columna)]
        else:
            laberinto = laberinto[:-1]

    # Agrega los bordes para que no se salgan los personajes
    matriz += [[1 for _ in range(columnas)]]
    for borde in matriz:
        borde += [1]
    # Se coloca con "i" y "f" para el resto del código del programa
    matriz[fila_inicio][columna_inicio] = 'i'  # Inicio primer jugador
    matriz[fila_inicio2][columna_inicio2] = 'i2'  # Inicio segundo jugador
    matriz[salida][columnas - 1] = 'f'  # fin del laberinto
    return matriz

# Se encarga de saber si hay al menos una entrada o una salida


def identificar_solucion(laberinto):
    global cantidad_fila
    cantidad_columnas = len(laberinto[0])
    cuadros_lab = [[0 for j in range(cantidad_columnas)]
                   for i in range(cantidad_fila)]

    inicio = False
    final = False
    for i in range(cantidad_fila):
        for j in range(cantidad_columnas):
            if laberinto[i][j] == 'i':
                inicio = (i, j)
            elif laberinto[i][j] == 'f':
                final = (i, j)
    if inicio == False or final == False:
        return False

    if identificar_solucion_Aux(inicio[0], inicio[1], final, cuadros_lab, cantidad_fila, cantidad_columnas, laberinto):
        return True
    else:
        return False

# Agrega los caminos a una lista


def identificar_solucion_Aux(fila_sig, columna_sig, final, cuadros_lab, cantidad_fila, cantidad_columnas, laberinto):
    global camino, laberinto_level_1
    matriz = laberinto_level_1

    if fila_sig == final[0] and columna_sig == final[1]:
        return True

# En la función anterior se crea una  matriz con puros 0
# En las líneas siguientes se marcan con un 1 para indicar
# que son paredes y de esta manera el programa no vuelva
# a ir a dicho cuadro de la matriz
    cuadros_lab[fila_sig][columna_sig] = 1

    # Misma idea acerca de los cuadros cercanos en base a [1]

    cuadros_cercanos = [(0, 1), (1, 0), (0, -1), (-1, 0)
                        ]  # Movimientos permitidos

    for cuadro_x, cuadro_y in cuadros_cercanos:
        sig_x = fila_sig + cuadro_x
        sig_y = columna_sig + cuadro_y

        # Se valida que no se salga del rango del laberinto y que no sea una pared o que no esté visitado
        if sig_x >= 0 and sig_x < cantidad_fila and sig_y >= 0 and sig_y < cantidad_columnas and not cuadros_lab[sig_x][sig_y] and laberinto[sig_x][sig_y] != 1:

            # Se añade a una lista para luego colocar las flechas
            if laberinto[sig_x][sig_y] != 'f':
                camino += [(sig_x, sig_y)]

            # Se realiza la llamada recursiva a sí misma
            if identificar_solucion_Aux(sig_x, sig_y, final, cuadros_lab, cantidad_fila, cantidad_columnas, laberinto):
                return True
    return False


def mostrarSolucion(solucion, screen, matriz):
    global espaciado_x, espaciado_y, flecha, camara_x, camara_y, resolver, x_personaje, y_personaje

    y = 20
    x = 20
    fila_laberinto = 0

    for indice_fila, fila in enumerate(range(len(matriz))):
        for indice_columna, campo in enumerate(matriz[fila_laberinto]):
            cuadro = pygame.Rect(x, y, espaciado_x, espaciado_y)
            if (indice_fila, indice_columna) in camino:
                solucion.append(cuadro)
            x += espaciado_x
        y += espaciado_y
        x = 20
        fila_laberinto += 1

    for indice_x, casilla in enumerate(solucion):
        if indice_x < len(solucion)-1:

            posicion = solucion[indice_x].x, solucion[indice_x].y
            posicionDe = solucion[indice_x+1].x, solucion[indice_x+1].y

            screen.blit(flecha, casilla.move(-camara_x, -camara_y))
            x_personaje = casilla.x
            y_personaje = casilla.y

    resolver = False

# Coloca la pared y el suelo


def colocarlaberinto(pantalla, camara_x, camara_y):
    global prohibidos, suelo, pared, salidas_laberinto, suelo
    for l in prohibidos:
        pygame.draw.rect(pantalla, (100, 100, 100),
                         l.move(-camara_x, -camara_y))
        pantalla.blit(pared, l.move(-camara_x, -camara_y))

    for j in suelo:
        pantalla.blit(suelo_tex, j.move(-camara_x, -camara_y))

    for m in pared_:
        pantalla.blit(pared, m.move(-camara_x, -camara_y))

    for o in salidas_laberinto:
        pantalla.blit(banderaSalida, o.move(-camara_x, -camara_y))
# -------------------------------------------------- FUNCIONES-----------------------------------------------
# Para guardar puntaje en archivo texto plano

# Idea para generar una función que guarde un puntaje sacada de [2]:

# [2] AlberM. "¿Cómo modifico una linea de un fichero en Python?" Stack Overflow en español.
# https://es.stackoverflow.com/questions/35491/cómo-modifico-una-linea-de-un-fichero-en-python (accedido el 24 de mayo de 2023).


def guardarPuntaje(puntajeLoc):
    global texto_input, textos
    with open('puntajeLaberinto.txt', 'r', encoding='utf-8') as P:
        if texto_input not in P.read():
            textos.append('\n'+texto_input+':'+str(puntajeLoc)+':')
            texto_input = ''
        else:
            pass
    with open('puntajeLaberinto.txt', 'w', encoding='utf-8') as P:
        P.writelines(textos)


def pantallaMuerte(superficieP, textoM):
    superficieP.fill((0, 0, 0))
    textoGameOver = gameOverFont.render(textoM, True, (255, 255, 255))
    superficieP.blit(textoGameOver, (300, 80))
    pantalla.blit(superficieP, (200, 200))
    btnAceptarGameOver.pintar()


def imagenesAmbiente(imagenBoton, imagenPer, imagenPer2, enemigo1, enemigo2, colorBot1, colorBot2, colorTxt):
    global imagenBT, imagenPersonaje, imagenPersonaje2, colorBotones1, colorBotones2, colorTexto
    imagenBT = pygame.image.load(imagenBoton)

    imagenPersonaje = imagenPer
    imagenPersonaje2 = imagenPer2

    personaje.set_imagen(imagenPer)
    personaje2.set_imagen(imagenPer2)

    enemigo_congelante.set_imagen(enemigo1)
    enemigo_congelante2.set_imagen(enemigo1)

    enemigo_asesino.set_imagen(enemigo2)
    enemigo_asesino2.set_imagen(enemigo2)

    colorBotones1 = colorBot1
    colorBotones2 = colorBot2
    colorTexto = colorTxt


# -------------------------------------------------------------Ventana Emergente---------------------------------------
# Identificar en que sistema se está trabajando y abrir el directorio principal de acuerdo al  sistema
if sys.platform.startswith('win32'):
    # os.system('start .')
    directorio_principal = os.environ['USERPROFILE']
elif sys.platform.startswith('linux'):
    # os.system('xdg-open .')
    directorio_principal = os.environ['HOME']

guardar_directorio_inicial = directorio_principal
lista_archivos_totales = os.listdir(path=directorio_principal)

# Botones de la ventana
btn_aceptar_Archivo = Boton(
    'Aceptar', pygame.Rect(450, 650, 100, 50), pantalla, 0)
btn_cancelar_Archivo = Boton(
    'Cancelar', pygame.Rect(320, 650, 100, 50), pantalla, 0)
btn_anterior_directorio = Boton(
    'Atrás', pygame.Rect(200, 650, 100, 50), pantalla, 0)

# Ubicacion archivos de la ventana
y_archivo = 20
x_archivo = 20

# Para saber que buscar
Buscar = ''
archivo_seleccionado = False
nombre_archivo_seleccionado = ''

exploradorArchivos = pygame.Surface((600, 800))
ventana_dialogo_archivos = 1

# Variables para el control de extensión soportada
archivo_permitido = ['.txt']
archivo_audio_permitido = ['.mp3', '.txt', '.ogg']
todos_permitidos = False

# Carpeta que se muestra
carpeta_principal = [files for files in lista_archivos_totales if
                     os.path.isfile(os.path.join(directorio_principal, files)) and (
                         files[-4:] in archivo_permitido) or os.path.isdir(
                         os.path.join(directorio_principal, files))]
# -------------------------------------------------------------------------------------------------------------


# Colores para los botones y el texto
colorBotones1 = (64, 128, 128)
colorBotones2 = (46, 90, 90)
colorTexto = (255, 255, 255)

direccion_personaje = 'derecha'

# Crea los personajes
personaje = Personaje('jugador 1', espaciado_x, espaciado_y,
                      pantalla, imagenPersonaje, x_personaje, y_personaje)
personaje2 = Personaje('jugador 2', espaciado_x, espaciado_y,
                       pantalla2, imagenPersonaje2, x_personaje2, y_personaje2)

# Crea al enemigo
enemigo_congelante = Enemy(
    [2, 2], pantalla, 'imagenes/monstruoPiedra.png', 'congelación')
enemigo_asesino = Enemy([2, 2], pantalla, 'imagenes/asesino.png', 'muerte')

enemigo_congelante2 = Enemy(
    [2, 2], pantalla2, 'imagenes/monstruoPiedra.png', 'congelación')
enemigo_asesino2 = Enemy([2, 2], pantalla2, 'imagenes/asesino.png', 'muerte')

reiniciar_posiciones = False

# Para botones
cuadroPregunta = False
aleatorio = False
preguntaTamaño = False
tamañoX = ''
tamañoY = ''
listoCargar = False
cambio_ambiente = 1
ambienteSeleccionado = ''
# ----------------------------BOTONES-----------------------------------------------------------------------------------
btnAmbiente = Boton('Ambiente', pygame.Rect(100, 50, 100, 50),
                    pantalla, 0, imagenBT, (100, 50), (100, 50))
btnCompeticion = Boton('Modo Competicion', pygame.Rect(
    250, 50, 155, 50), pantalla, 0, imagenBT, (155, 50), (250, 50))
btnSalir = Boton('Salir', pygame.Rect(470, 50, 100, 50),
                 pantalla, 0, imagenBT, (100, 50), (470, 50))
btnUsuarioSimple = Boton(
    'Usuario Simple', pygame.Rect(800, 50, 140, 50), pantalla, 0, imagenBT, (140, 50), (800, 50))
btnAventuraLaberinto = Boton(
    'Modo Aventura', pygame.Rect(1000, 50, 100, 50), pantalla, 0, imagenBT, (100, 50), (1000, 50))
btnScore = Boton('Tabla de Clasificaciones', pygame.Rect(
    500, 600, 250, 50), pantalla, 0, imagenBT, (250, 50), (500, 600))
btnSiguiente = Boton('Siguiente', pygame.Rect(
    850, 360, 80, 50), pantalla, 0, imagenBT, (80, 50), (850, 360))
btnAtras = Boton('Anterior', pygame.Rect(680, 360, 80, 50),
                 pantalla, 0, imagenBT, (80, 50), (680, 360))
btnSolucion = Boton('Solucion', pygame.Rect(1000, 25, 100, 50),
                    pantalla, 0, imagenBT, (100, 50), (1000, 25))
btnSolucion2 = Boton('Solucion', pygame.Rect(880, 0, 100, 50),
                     pantalla, 0, imagenBT, (100, 50), (880, 0))
btnCancelarSimple = Boton('Cancelar', pygame.Rect(600, 420, 100, 50),
                          pantalla, 0, imagenBT, (100, 50), (600, 420))
btnAlmacenarPuntaje = Boton(
    'Guardar Puntaje', pygame.Rect(820, 470, 150, 50), pantalla, 0, imagenBT, (150, 50), (820, 470))
btnAbandonar = Boton('Abandonar Partida', pygame.Rect(
    1000, 0, 155, 50), pantalla, 0, imagenBT, (155, 50), (1000, 0))
btnCancelarGuardar = Boton(
    'Cancelar', pygame.Rect(700, 470, 100, 50), pantalla, 0, imagenBT, (100, 50), (700, 470))
btnGenerar = Boton('Generar automaticamente',
                   pygame.Rect(600, 300, 250, 50), pantalla, 0, imagenBT, (250, 50), (600, 300))
btnCargarLaberinto = Boton(
    'Cargar Laberinto', pygame.Rect(400, 300, 170, 50), pantalla, 0, imagenBT, (170, 50), (400, 300))
btnAceptarTamaño = Boton('Aceptar', pygame.Rect(
    450, 200, 100, 50), pantalla, 0, imagenBT, (100, 50), (450, 200))
btnCancelarTamaño = Boton(
    'Cancelar', pygame.Rect(650, 200, 100, 50), pantalla, 0, imagenBT, (100, 50), (650, 200))
btnAceptarSol = Boton('OK', pygame.Rect(550, 350, 100, 50),
                      pantalla, 0, imagenBT, (100, 50), (550, 350))

btnHelado = Boton('Helado', pygame.Rect(210, 150, 100, 50),
                  pantalla, 0, imagenBT, (100, 50), (210, 150))
btnApocaliptico = Boton('Apocalíptico', pygame.Rect(
    60, 150, 100, 50), pantalla, 0, imagenBT, (100, 50), (60, 150))
btnAceptarGameOver = Boton('Continuar', pygame.Rect(
    575, 400, 100, 50), pantalla, 0, imagenBT, (100, 50), (575, 400))
# ----------------------------EVENTOS----------------------------------------------------------------------------------

while running:
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN and (puntaje_activado == True or preguntaTamaño == True):
            tamaño = len(texto_input)
            if pygame.key.name(event.key) == 'backspace':
                tamaño = len(texto_input)
                if tamaño > 0:
                    texto_input = texto_input[:tamaño - 1]
            else:
                if tamaño >= 3:
                    texto_input = texto_input[:tamaño - 1]
                # Restringe los caracteres prohibidos
                if puntaje_activado == True:
                    for letra in caract:
                        if pygame.key.name(
                                event.key) == letra and not pygame.key.get_mods() & pygame.K_LCTRL and not pygame.key.get_mods() & pygame.K_RSHIFT and not pygame.key.get_mods() & pygame.KMOD_RSHIFT:
                            texto_input += event.unicode
                elif preguntaTamaño == True:
                    for num in numeros:
                        if pygame.key.name(
                                event.key) == num and not pygame.key.get_mods() & pygame.K_LCTRL and not pygame.key.get_mods() & pygame.K_RSHIFT and not pygame.key.get_mods() & pygame.KMOD_RSHIFT:
                            texto_input += event.unicode

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = pygame.mouse.get_pos()  # Detectar la posición del mouse

            if btnAceptarGameOver.getForma().collidepoint(pos) and cuadroMuerte == True:
                cuadroMuerte = False

            if btnGenerar.getForma().collidepoint(pos) and puntaje_activado == False and jugando == False and cuadroPregunta == True and not preguntaTamaño:
                tamañoX = ''
                tamañoY = ''
                preguntaTamaño = True
                modo_juego = modo

            if btnScore.getForma().collidepoint(pos) and puntaje_activado == False and jugando == False and cuadroPregunta == False and not preguntaTamaño:
                puntaje_activado = True

            if btnSiguiente.getForma().collidepoint(pos) and puntaje_activado == True:
                min += 8
                max += 8

            if btnAtras.getForma().collidepoint(pos) and puntaje_activado == True:
                min -= 8
                max -= 8

            # Para colocar el tamaño del laberinto
            if btnAceptarTamaño.getForma().collidepoint(pos) and preguntaTamaño:
                compet = False
                per1 = False
                per2 = False
                if len(texto_input) > 0 and tamañoX == '' and int(texto_input) >= 50:
                    tamañoX = texto_input
                    texto_input = ''
                elif len(texto_input) > 0 and tamañoX != '' and int(texto_input) >= 50:
                    tamañoY = texto_input
                    texto_input = ''
                    listoCargar = True
                    preguntaTamaño = False
                    if modo_juego == 'simple':
                        cuadroPregunta = False
                        aleatorio = True
                        cambio_nivel = True
                        puntaje = 0
                        puntaje2 = 0
                    elif modo_juego == 'Aventura':
                        pantalla = pygame.display.set_mode(
                            (1280, 720), pygame.RESIZABLE)
                        cambio_nivel = True
                        jugando = True

                    elif modo_juego == 'Competitivo':
                        jugando = True
                        cambio_nivel = True
                    puntaje = 0
                    puntaje2 = 0

            if btnUsuarioSimple.getForma().collidepoint(pos) and puntaje_activado == False and jugando == False and cuadroPregunta == False and not preguntaTamaño and cambio_ambiente > 0:
                cuadroPregunta = True
                modo = 'simple'

            if btnCancelarTamaño.getForma().collidepoint(pos) and preguntaTamaño == True:
                cuadroPregunta = False
                preguntaTamaño = False

            if btnSalir.getForma().collidepoint(pos) and puntaje_activado == False and jugando == False and not preguntaTamaño:
                running = False

            if btnCancelarGuardar.getForma().collidepoint(pos) and puntaje_activado == True:
                puntaje_activado = False

            if btnCancelarSimple.getForma().collidepoint(pos) and puntaje_activado == False and not preguntaTamaño:
                cuadroPregunta = False

            if btnAbandonar.getForma().collidepoint(pos) and jugando == True and puntaje_activado == False:
                modo_juego = 'finalizado'
                nivel_laberinto = 0

            if btnAmbiente.getForma().collidepoint(pos) and puntaje_activado == False and jugando == False and not preguntaTamaño:
                cambio_ambiente *= -1

            if btnAlmacenarPuntaje.getForma().collidepoint(pos) and puntaje_activado == True and len(texto_input) > 0:
                if competitivoPuntos == True:
                    if puntaje != 0:
                        guardarPuntaje(puntaje)
                        puntaje = 0
                    else:
                        print(puntaje2)
                        guardarPuntaje(puntaje2)
                        puntaje2 = 0
                        competitivoPuntos = False
                else:
                    guardarPuntaje(puntaje)
                    puntaje = 0

            if btnSolucion2.getForma().collidepoint(pos) and jugando == True:
                resolver = True

            if btnAceptarSol.getForma().collidepoint(pos) and HaySolucion == False:
                HaySolucion = True

            if btnCompeticion.getForma().collidepoint(pos) and puntaje_activado == False and jugando == False and cuadroPregunta == False and not preguntaTamaño and cambio_ambiente > 0:
                tamañoX = ''
                tamañoY = ''
                preguntaTamaño = True
                modo_juego = 'Competitivo'

            # Ambientes
            if btnHelado.getForma().collidepoint(pos) and cambio_ambiente < 0:
                ambienteSeleccionado = 'Helado'
                imagenesAmbiente('imagenes/BotonCongelado2.png', 'imagenes/personajeHelado.png', 'imagenes/personaje2Helado.png',
                                 'imagenes/enemigoHelado.png', 'imagenes/enemigo2Helado.png', (255, 255, 255), (200, 200, 200), (0, 0, 0))
                imagenPersonaje = 'imagenes/personajeHelado.png'
                imagenPersonaje2 = 'imagenes/personaje2Helado.png'
                cambio_ambiente *= -1

            if btnApocaliptico.getForma().collidepoint(pos) and cambio_ambiente < 0:
                ambienteSeleccionado = 'Apocaliptico'
                imagenesAmbiente('imagenes/BotonLava.png', 'imagenes/personajeApocaliptico.png', 'imagenes/personaje2Apocaliptico.png',
                                 'imagenes/enemigoApocaliptico.png', 'imagenes/enemigo2Apocaliptico.png', (121, 0, 3,), (0, 0, 0), (255, 255, 255))
                imagenPersonaje = 'imagenes/personajeApocaliptico.png'
                imagenPersonaje2 = 'imagenes/personaje2Apocaliptico.png'
                cambio_ambiente *= -1

# ----------------------------------------------------------Ventana de Archivos----------------------------------------------------------------
            if btnCargarLaberinto.getForma().collidepoint(pos) and ventana_dialogo_archivos > 0 and jugando == False and puntaje_activado == False and cuadroPregunta:
                ventana_dialogo_archivos *= -1
                Buscar = 'archivo'
                cuadroPregunta = False

            if ventana_dialogo_archivos < 0:
                y_archivo = 20  # Posicion inicial del archivo
                x_archivo = 20  # Posicion inicial del archivo

                # Toma cada archivo de las lista
                for numeroArchivo, file in enumerate(carpeta_principal):

                    if y_archivo > 600:  # Para evitar salir de la pantalla
                        x_archivo += 300
                        y_archivo = 20
                    btnArchivo = pygame.Rect(x_archivo, y_archivo, 200, 20)
                    y_archivo += 30

                    # Boton para cuando lo seleccionado es una carpeta
                    if btnArchivo.collidepoint(pos):

                        nombre_archivo_seleccionado = file
                        if os.path.isdir(os.path.join(directorio_principal, file)):
                            exploradorArchivos.fill((0, 0, 0))
                            directorio_principal = directorio_principal + '/' + file
                            lista_archivos_totales = os.listdir(
                                path=directorio_principal)

                            # Carpeta donde está todo lo que se muesta en pantalla
                            carpeta_principal = [files for files in lista_archivos_totales if
                                                 os.path.isfile(os.path.join(directorio_principal, files)) and (
                                                     files[-4:] in archivo_permitido) or os.path.isdir(
                                                     os.path.join(directorio_principal, files))]

                            # Ruta del directorio
                            ruta_archivo = directorio_principal
                            archivo_seleccionado = True

                        # Boton para cuando lo seleccionado es un archivo
                        if os.path.isfile(os.path.join(directorio_principal, file)) and Buscar == 'archivo':
                            # Ruta del laberinto
                            laberintoAñadido = directorio_principal + '/' + nombre_archivo_seleccionado

                # Evento del boton para mostrar los archivos en el directorio anterior
                if btn_anterior_directorio.getForma().collidepoint(
                        pos) and directorio_principal != guardar_directorio_inicial and ventana_dialogo_archivos < 0:
                    exploradorArchivos.fill((0, 0, 0))
                    directorio_principal = os.path.dirname(
                        directorio_principal)
                    lista_archivos_totales = os.listdir(
                        path=directorio_principal)
                    carpeta_principal = [files for files in lista_archivos_totales if
                                         os.path.isfile(os.path.join(directorio_principal, files)) and (
                                             files[-4:] in archivo_permitido) or os.path.isdir(
                                             os.path.join(directorio_principal, files))]

                # Para cargar el archivo, una accion diferente para cuando es un archivo o directorio
                if btn_aceptar_Archivo.getForma().collidepoint(
                        pos) and ventana_dialogo_archivos < 0 and archivo_seleccionado != '':

                    if nombre_archivo_seleccionado[-4:] in archivo_permitido and Buscar == 'archivo':

                        # Leer el contenido del archivo y lo asigna al laberinto
                        with open(laberintoAñadido, 'r') as f:
                            contenido = f.read()
                        laberinto_level_1 = eval(contenido)
                        personaje_no_movido = True

                        cantidad_fila = len(laberinto_level_1)
                        suelo = []
                        pared_ = []
                        cuadros = []
                        posicion_suelo = []
                        movimiento_monstruos = []

                        colocar_laberinto = True
                        if colocar_laberinto == True:
                            for fila in range(cantidad_fila):
                                for indice, campo in enumerate(laberinto_level_1[fila_laberinto]):
                                    # Cuadro de cada laberinto
                                    cuadro = pygame.Rect(
                                        x, y, espaciado_x, espaciado_y)

                                    if campo == 1:
                                        pared_.append(cuadro)
                                        movimiento_monstruos.append(cuadro)

                                    elif campo == 0 or campo == 'i' or campo == 'f':
                                        suelo.append(cuadro)

                                        if campo == 0 and indice >= 8:
                                            posicion_suelo += [(x, y)]

                                        if campo == 'i' and personaje_no_movido == True:
                                            # Toma las posiciones de inicio de los personaje
                                            x_personaje, y_personaje = x, y
                                            x_personaje2, y_personaje2 = x, y
                                            # Limita el movimiento a esa posicion
                                            movimiento_monstruos.append(cuadro)

                                    x += espaciado_x
                                y += espaciado_y
                                x = 20
                                fila_laberinto += 1

                            y = 20
                            fila_laberinto = 0
                            efecto_congelacion_player1 = False

                        laberintoAñadido = directorio_principal + '/' + nombre_archivo_seleccionado
                        ventana_dialogo_archivos *= -1
                        modo_juego = modo
                        jugando = True
                        pygame.display.update()
                if btn_cancelar_Archivo.getForma().collidepoint(pos) and ventana_dialogo_archivos < 0:
                    ventana_dialogo_archivos *= -1

# ---------------------------------------------------- Evento para el modo aventura--------------------------------------
            if btnAventuraLaberinto.getForma().collidepoint(pos) and jugando == False and puntaje_activado == False and cuadroPregunta == False and not preguntaTamaño and cambio_ambiente > 0:
                preguntaTamaño = True
                modo_juego = 'Aventura'

    if (modo_juego == 'Competitivo' or modo_juego == 'Aventura' or aleatorio) and cambio_nivel == True:
        tiempoRestante = 5*60
        listoCargar = False
        jugando = True
        nivel_laberinto += 1

        if nivel_laberinto == 1:

            if ambienteSeleccionado == 'Helado':
                suelo_tex = pygame.image.load('imagenes/nieve.jpg')
                pared = pygame.image.load('imagenes/hielo.jpg')

            if ambienteSeleccionado == 'Apocaliptico':
                suelo_tex = pygame.image.load('imagenes/sueloApocaliptico.jpg')
                pared = pygame.image.load('imagenes/ParedLava.jpg')

            suelo_tex = pygame.transform.scale(
                suelo_tex, (espaciado_x, espaciado_y))
            pared = pygame.transform.scale(pared, (espaciado_x, espaciado_y))

        if nivel_laberinto == 2:
            if modo_juego == 'simple':
                simple = True
                nivel_laberinto = 5

            suelo_tex = pygame.transform.scale(
                suelo_tex, (espaciado_x, espaciado_y))
            pared = pygame.transform.scale(pared, (espaciado_x, espaciado_y))

        if nivel_laberinto == 3:

            suelo_tex = pygame.transform.scale(
                suelo_tex, (espaciado_x, espaciado_y))
            pared = pygame.transform.scale(pared, (espaciado_x, espaciado_y))

        if nivel_laberinto == 4:

            suelo_tex = pygame.transform.scale(
                suelo_tex, (espaciado_x, espaciado_y))
            pared = pygame.transform.scale(pared, (espaciado_x, espaciado_y))

        mostrar = False
        # Reinicia las variables y posiciones
        enemigo_congelante2.set_reinicio(True)
        enemigo_asesino2.set_reinicio(True)
        enemigo_congelante.set_reinicio(True)
        enemigo_asesino.set_reinicio(True)
        # Aumenta puntaje
        if modo_juego != 'Competitivo':
            puntaje += tiempoRestante
        else:
            competitivoPuntos = True
        # Crea un laberinto nuevo
        suelo = []
        pared_ = []
        cuadros = []
        posicion_suelo = []
        movimiento_monstruos = []
        salidas_laberinto = []

        laberinto_level_1 = generar_laberinto(int(tamañoX), int(tamañoY))
        cantidad_fila = len(laberinto_level_1)
        colocar_laberinto = True

        # Reinicia efecto
        efecto_congelacion_player1 = False
        efecto_congelacion_player2 = False
        descongelando_player1 = False
        descongelando_player2 = False

        personaje_no_movido = True

        for fila in range(cantidad_fila):
            for indice, campo in enumerate(laberinto_level_1[fila_laberinto]):
                cuadro = pygame.Rect(x, y, espaciado_x, espaciado_y)

                if campo == 1:
                    pared_.append(cuadro)
                    movimiento_monstruos.append(cuadro)

                elif campo == 0 or campo == 'i' or campo == 'f' or campo == 'i2':
                    suelo.append(cuadro)

                    if campo == 0 and indice >= 8:
                        posicion_suelo += [(x, y)]

                    if campo == 'i' and personaje_no_movido == True:
                        x_personaje, y_personaje = x, y

                    if campo == 'i2' and personaje_no_movido == True:
                        x_personaje2, y_personaje2 = x, y

                        x_per_inicial, y_per_inicial = x, y
                        movimiento_monstruos.append(cuadro)

                    if campo == 'f':
                        salidas_laberinto += [cuadro]
                        # movimiento_monstruos.append(cuadro)

                x += espaciado_x
            y += espaciado_y
            x = 20
            fila_laberinto += 1

        y = 20
        x = 20
        fila_laberinto = 0

        cambio_nivel = False
# ----------------------------------------------------------------------------------------------------------------------

# --------------------------------------------------------------Renderización-------------------------------------------

    pantalla.fill((255, 255, 255))
    pantalla.blit(fondo, (0, 0))
    # Ventana de dialogo y tiempo
    if ventana_dialogo_archivos > 0:
        btnAventuraLaberinto.pintar()
        btnCompeticion.pintar()
        btnSalir.pintar()
        btnUsuarioSimple.pintar()
        btnAmbiente.pintar()
        btnScore.pintar()

# --------------------------------------------------- Acá empieza todo lo relacionado con el laberinto-------------------------------------

    if colocar_laberinto == False:
        muerte_player1 = False
        muerte_player2 = False
        efecto_congelacion_player1 = False
        efecto_congelacion_player2 = False
        nivel_laberinto = 0

    if colocar_laberinto == True:
        if nivel_laberinto == 1:
            puntaje = 0
# ----------------------------------------------------------Terminar nivel ---------------------------------------------
        for salida in salidas_laberinto:
            if salida.collidepoint(x_personaje, y_personaje):
                mostrar = False
                cuadrosSolucion = []
                camino = []
                cambio_nivel = True
                puntaje += tiempoRestante
                puntaje2 += tiempoRestante//2
            if modo_juego == 'Competitivo' and salida.collidepoint(x_personaje2, y_personaje2):
                mostrar = False
                cuadrosSolucion = []
                camino = []
                cambio_nivel = True
                puntaje += tiempoRestante//2
                puntaje2 += tiempoRestante

        # Control del tiempo
        tiempo += 1
        if tiempo == 60:
            tiempoRestante -= 1
            text_t = fuente.render(
                f'Tiempo: {tiempoRestante}', True, (255, 255, 255))
            tiempo = 0

        text_nivel = fuente.render(
            f'Nivel: {nivel_laberinto}', True, (255, 255, 255))
        text_puntaje = fuente.render(
            f'Puntaje jugador 1: {puntaje}', True, (255, 255, 255))
        text_puntaje2 = fuente.render(
            f'Puntaje jugador 2: {puntaje2}', True, (255, 255, 255))

        # Dimensiones del laberinto
        alto_mundo = len(laberinto_level_1) * espaciado_y
        ancho_mundo = len(laberinto_level_1[0]) * espaciado_x

# Ajusta la cámara dependiendo del modo de juego
# Ajusta las posiciones del enemigo en relación a la camara de seguimiento
# Además lo coloca en el mapa
        if modo_juego == 'Aventura' or modo_juego == 'simple':

            enemigo_congelante.set_screen(pantalla)
            enemigo_asesino.set_screen(pantalla)
            if camara_x < 0:
                camara_x = 0
            elif camara_x > ancho_mundo - 1280:
                camara_x = ancho_mundo - 1280
            if camara_y < 0:
                camara_y = 0
            elif camara_y > alto_mundo - 720:
                camara_y = alto_mundo - 720

            colocarlaberinto(pantalla, camara_x, camara_y)

            if resolver == True:

                if identificar_solucion(laberinto_level_1) == False:
                    HaySolucion = False
                    resolver = False
                else:
                    identificar_solucion(laberinto_level_1)
                    mostrarSolucion(cuadrosSolucion, pantalla,
                                    laberinto_level_1)
                    mostrar = True

            if mostrar == True:
                for camino_sol in cuadrosSolucion:
                    pantalla.blit(
                        flecha, camino_sol.move(-camara_x, -camara_y))

        if modo_juego == 'Competitivo':
            # Primer Jugador Cámara
            if camara_x < 0:
                camara_x = 0
            elif camara_x > ancho_mundo - 1280:
                camara_x = ancho_mundo - 1280
            if camara_y < 0:
                camara_y = 0
            elif camara_y > alto_mundo - 360:
                camara_y = alto_mundo - 360

            # Segundo Jugador Cámara
            if camara_x2 < 0:
                camara_x2 = 0
            elif camara_x2 > ancho_mundo - 1280:
                camara_x2 = ancho_mundo - 1280
            if camara_y2 < 0:
                camara_y2 = 0
            elif camara_y2 > alto_mundo - 360:
                camara_y2 = alto_mundo - 360

            # Coloca el mismo laberinto a ambos jugadores
            colocarlaberinto(pantalla1, camara_x, camara_y)
            colocarlaberinto(pantalla2, camara_x2, camara_y2)

            # Modifica la pantalla de los enemigos del primer personaje
            enemigo_congelante.set_screen(pantalla1)
            enemigo_asesino.set_screen(pantalla1)

# ---------------------------------------Código para el enemigo que congela----------------------------------------------
        if nivel_laberinto == 2 or nivel_laberinto == 4:
            enemigo_congelante.update()
            enemigo_congelante.colocar(camara_x, camara_y)

            if modo_juego == 'Competitivo':
                enemigo_congelante2.update()
                enemigo_congelante2.colocar(camara_x2, camara_y2)

            # Código para el efecto de congelación del player1
            if efecto_congelacion_player1 == False and descongelando_player1 == False:
                tiempo_congelacion_player1 = 10 * 90

            elif efecto_congelacion_player1 == True or descongelando_player1 == True:
                tiempo_congelacion_player1 -= 1

                if 0 <= tiempo_congelacion_player1 < 300:
                    personaje.set_imagen(imagenPersonaje)
                    efecto_congelacion_player1 = False
                    descongelando_player1 = True

                elif tiempo_congelacion_player1 >= 300:
                    personaje.set_imagen('imagenes/congelado.png')
                elif tiempo_congelacion_player1 < 0:
                    descongelando_player1 = False

            # Código para el efecto de congelación del player2
            if efecto_congelacion_player2 == False and descongelando_player2 == False:
                tiempo_congelacion_player2 = 10 * 90

            elif efecto_congelacion_player2 == True or descongelando_player2 == True:
                tiempo_congelacion_player2 -= 1

                if 0 <= tiempo_congelacion_player2 < 300:
                    personaje2.set_imagen(imagenPersonaje2)
                    efecto_congelacion_player2 = False
                    descongelando_player2 = True

                elif tiempo_congelacion_player2 >= 300:
                    personaje2.set_imagen('imagenes/congelado.png')

                elif tiempo_congelacion_player2 < 0:
                    descongelando_player2 = False

# -------------------------------------# fin código del enemigo que congela----------------------------------------------

# ---------------------------------------Código para el enemigo asesino-------------------------------------------------
        # Ajusta las posiciones del enemigo en relación a la camara de seguimiento
        # Además lo coloca en el mapa
        if nivel_laberinto == 3 or nivel_laberinto == 4:
            enemigo_asesino.update()
            enemigo_asesino.colocar(camara_x, camara_y)

            if modo_juego == 'Competitivo':
                enemigo_asesino2.update()
                enemigo_asesino2.colocar(camara_x2, camara_y2)

            # Código para el efecto de muerte de los personajes
            # if efecto_congelacion_player1 == False:
            #   tiempo_congelacion_player1 = 5 * 60

# -------------------------------------# fin código del enemigo asesino-------------------------------------------------

        # Coloca el personaje y escala la camara
        if muerte_player1 == False:
            personaje.update()

        camara_x = x_personaje - (1280 / 2)
        camara_y = y_personaje - (720 / 2) / 2

        if modo_juego == 'Competitivo' and muerte_player2 == False:
            personaje2.update()

            camara_x2 = x_personaje2 - (1280 / 2)
            camara_y2 = y_personaje2 - (720 / 2) / 2

# -----------------------------------------------Para terminar el modo aventura y competitivo-------------------------
    if nivel_laberinto == 5 or tiempoRestante < 0:
        if tiempoRestante < 0:
            cuadroMuerte = True
            timeOver = True
        muerte_player1 = False
        muerte_player2 = False
        puntajeTotal = puntaje
        colocar_laberinto = False
        nivel_laberinto = 0
        modo_juego = 'finalizado'

    if cuadroPregunta:
        simpleSurf = pygame.Surface((500, 100))
        simpleSurf.fill((70, 70, 70))
        pantalla.blit(simpleSurf, (360, 275))
        btnCargarLaberinto.pintar()
        btnGenerar.pintar()
        btnCancelarSimple.pintar()

    if modo_juego == 'finalizado':
        per1 = False
        per2 = False
        timeOver = False
        tamañoX = ''
        tamañoY = ''
        jugando = False
        colocar_laberinto = False
        tiempoRestante = 5 * 60

    if jugando == True:
        Datos = pygame.Surface((700, 50))
        Datos.fill((0, 0, 0))
        Datos.blit(text_t, (10, 10))
        Datos.blit(text_puntaje, (160, 3))
        if modo_juego == 'Competitivo':
            Datos.blit(text_puntaje2, (160, 25))
        Datos.blit(text_nivel, (370, 10))
        pantalla.blit(Datos, (20, 0))
        btnSolucion2.pintar()
        btnAbandonar.pintar()

    if muerte_player1:
        cuadroMuerte = True
        if muerte_player2:
            nivel_laberinto = 5
            cuadroMuerte = True

    if cuadroMuerte:
        if timeOver:
            pantallaMuerte(pygame.Surface((1000, 300)), '¡Se acabó el tiempo!')
        elif avent or simple:
            pantallaMuerte(pygame.Surface((1000, 300)), '¡Has Muerto!')
        elif compet:
            print(per2, per1)
            if per1:
                textoPer1 = fuente.render(
                    'Jugador 1 ha muerto', True, (255, 255, 255))
                Datos.blit(textoPer1, (450, 3))
                pantalla.blit(Datos, (20, 0))
            elif per2:
                textoPer1 = fuente.render(
                    'Jugador 2 ha muerto', True, (255, 255, 255))
                Datos.blit(textoPer1, (450, 25))
                pantalla.blit(Datos, (20, 0))
    if preguntaTamaño == True:
        cuadroPregunta = False
        tam = pygame.Surface((400, 150))
        tam.fill((70, 70, 70))
        textoTamaño = fuente.render(
            f'Tamaño laberinto: {texto_input}', True, (255, 255, 255))
        tam.blit(textoTamaño, (120, 20))
        pantalla.blit(tam, (400, 120))
        btnAceptarTamaño.pintar()
        btnCancelarTamaño.pintar()

# ---------------------------------------------Puntaje---------------------------------------------------
    if puntaje_activado == True:
        score = pygame.Surface((1000, 500))
        score.fill((0, 0, 0))
        with open('puntajeLaberinto.txt', 'r') as P:
            tabla = P.read()
            board = tabla.split(':')
            esp = 0
            if max >= len(board)+6:
                max -= 8
                min -= 8
            if max <= 0:
                max += 8
                min += 8
            for num, ele in enumerate(board):
                if min <= num < max:
                    try:
                        int(ele)
                        textoTabla = fuente.render(ele, True, (0, 0, 0))
                        puntos = pygame.Rect(800, esp, 300, 50)
                        pygame.draw.rect(score, (255, 255, 255), puntos)
                        cantpuntos = textoTabla.get_rect()
                        cantpuntos.center = puntos.center
                        score.blit(textoTabla, puntos)
                        if esp < 250:
                            esp += 70
                    except:
                        if ele:
                            textoTabla = fuente.render(ele, True, (0, 0, 0))
                            puntos = pygame.Rect(400, esp, 300, 50)
                            pygame.draw.rect(score, (255, 255, 255), puntos)
                            cantpuntos = textoTabla.get_rect()
                            cantpuntos.center = puntos.center
                            score.blit(textoTabla, puntos)
        if competitivoPuntos:
            if puntaje != 0:
                introduzca = fuente.render(
                    'Introduzca su nombre (max 3 caracteres) jugador 1: ', True, (255, 255, 255))
            else:
                introduzca = fuente.render(
                    'Introduzca su nombre (max 3 caracteres) jugador 2: ', True, (255, 255, 255))
        else:
            introduzca = fuente.render(
                'Introduzca su nombre (max 3 caracteres): ', True, (255, 255, 255))
        textoPuntaje = fuente.render(texto_input, True, (255, 255, 255))
        score.blit(textoPuntaje, (100, 80))
        score.blit(introduzca, (10, 50))

        pantalla.blit(score, (60, 60))
        btnAlmacenarPuntaje.pintar()
        btnCancelarGuardar.pintar()
        btnSiguiente.pintar()
        btnAtras.pintar()

# ---------------------------------------------Termina parte del laberinto-------------------------------------

# ---------------------------------------------------únicamente Ventana----------------------------------------
    if ventana_dialogo_archivos < 0:
        pantalla.blit(exploradorArchivos, (0, 0))
        y_archivo = 20
        x_archivo = 20

        # Crea un boton para cada archivo en la carpeta
        for numeroArchivo, file in enumerate(carpeta_principal):
            if y_archivo > 600:  # Mueve las posiciones para evitar salir del rango de visión
                x_archivo += 300
                y_archivo = 20
            text = fuente.render(file, True, (0, 0, 0))
            # Boton de cada cancion
            btnArchivo = pygame.Rect(x_archivo, y_archivo, 200, 20)
            pygame.draw.rect(exploradorArchivos, (200, 200, 200), btnArchivo)
            numeroArchivo = file
            btnNombreArchivo = text.get_rect()  # Colocar nombre de cada canción en un botón
            btnNombreArchivo.center = btnArchivo.center  # Centra el texto
            exploradorArchivos.blit(text, btnNombreArchivo)

            y_archivo += 30
        y_archivo = 20

        # Botones principales de navegación
        btn_aceptar_Archivo.pintar()
        btn_cancelar_Archivo.pintar()
        btn_anterior_directorio.pintar()
        # Muestra en pantalla el archivo seleccionado
        if archivo_seleccionado:
            texto_archivo = fuente.render(
                'Archivo seleccionado: ' + nombre_archivo_seleccionado, True, (255, 255, 255))
            pantalla.blit(texto_archivo, (300, 600))

# --------------------------------------------Termina parte de la ventana de archivos----------------------------
    # Cambio de imagen personajes

    # personaje2

    if HaySolucion == False:
        ventanaNoSol = pygame.Surface((400, 200))
        mensajeNoSol = fuente.render(
            'LABERINTO SIN SOLUCIÓN', True, (255, 255, 255))
        ventanaNoSol.blit(mensajeNoSol, (50, 50))
        pantalla.blit(ventanaNoSol, (400, 250))
        btnAceptarSol.pintar()

    if cambio_ambiente < 0:
        ventana_ambiente = pygame.Surface((500, 500))
        btnHelado.pintar()
        btnApocaliptico.pintar()

    pygame.display.flip()
    clock.tick(60)
pygame.quit()
